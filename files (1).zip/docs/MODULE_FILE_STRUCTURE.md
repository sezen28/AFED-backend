# Tam Kapsamlı Afet Yönetim Sistemi – Modül Bazlı Detaylı Backend Dosya Yapısı

Her ana modül için önerilen dosya ve klasör yapısı, kurumsal düzeyde geliştirme, test ve sürdürülebilirlik için uygundur. Domain-driven, katmanlı ve profesyonel bir mimariyi yansıtır.

---

## Ortak Ana Yapı

```
src/
  modules/
    <modül-adi>/
      domain/
        <entity>.entity.ts
        <interface>.ts
        <value-object>.ts
      infrastructure/
        <repository>.ts
        <external-service>.ts
        <schema>.ts
      application/
        <service>.ts
        dto/
          <create>.dto.ts
          <update>.dto.ts
        <usecase>.ts
      presentation/
        <controller>.ts
        <resolver>.ts
        <route-guard>.ts
        <swagger>.ts
      test/
        <unit>/
        <integration>/
      <modül-adi>.module.ts
  shared/
    guards/
    decorators/
    filters/
    logger/
    utils/
    middlewares/
    constants/
  config/
    configuration.ts
    env/
      .env.dev
      .env.staging
      .env.prod
  main.ts
  app.module.ts
```

---

## 1. **auth** (Kimlik Doğrulama)
```
modules/auth/
  domain/
    auth-session.entity.ts
    auth.interface.ts
  infrastructure/
    auth.repository.ts
    mfa-provider.ts
  application/
    auth.service.ts
    dto/
      login.dto.ts
      mfa.dto.ts
      register.dto.ts
      refresh.dto.ts
    usecase/
      login.usecase.ts
      mfa.usecase.ts
  presentation/
    auth.controller.ts
    auth.swagger.ts
  test/
    unit/
    integration/
  auth.module.ts
```

## 2. **users** (Kullanıcı Profili)
```
modules/users/
  domain/
    user.entity.ts
    user-profile.value-object.ts
  infrastructure/
    users.repository.ts
  application/
    users.service.ts
    dto/
      create-user.dto.ts
      update-user.dto.ts
      child-profile.dto.ts
    usecase/
      delete-user.usecase.ts
  presentation/
    users.controller.ts
  test/
  users.module.ts
```

## 3. **alerts** (Afet Uyarı)
```
modules/alerts/
  domain/
    alert.entity.ts
  infrastructure/
    alerts.repository.ts
    social-crawler.ts
  application/
    alerts.service.ts
    dto/
      create-alert.dto.ts
      update-alert.dto.ts
  presentation/
    alerts.controller.ts
  test/
  alerts.module.ts
```

## 4. **map** (Harita)
```
modules/map/
  domain/
    shelter.entity.ts
    zone.entity.ts
  infrastructure/
    map.repository.ts
    geo.service.ts
  application/
    map.service.ts
    dto/
      create-shelter.dto.ts
      report-zone.dto.ts
  presentation/
    map.controller.ts
  test/
  map.module.ts
```

## 5. **community** (Topluluk Destek)
```
modules/community/
  domain/
    help-request.entity.ts
    help-offer.entity.ts
    message.entity.ts
  infrastructure/
    community.repository.ts
    messaging.service.ts
  application/
    community.service.ts
    dto/
      create-help-request.dto.ts
      create-missing-person.dto.ts
      send-message.dto.ts
  presentation/
    community.controller.ts
  test/
  community.module.ts
```

## 6. **ai** (Yapay Zeka Yardım)
```
modules/ai/
  domain/
    ai-interaction.entity.ts
    knowledge.entity.ts
  infrastructure/
    ai-client.ts
    knowledge.repository.ts
  application/
    ai.service.ts
    dto/
      ai-message.dto.ts
      feedback.dto.ts
  presentation/
    ai.controller.ts
  test/
  ai.module.ts
```

## 7. **knowledge** (Bilgi Kütüphanesi)
```
modules/knowledge/
  domain/
    knowledge.entity.ts
    quiz.entity.ts
  infrastructure/
    knowledge.repository.ts
    quiz.repository.ts
  application/
    knowledge.service.ts
    dto/
      create-knowledge.dto.ts
      answer-quiz.dto.ts
  presentation/
    knowledge.controller.ts
  test/
  knowledge.module.ts
```

## 8. **donations** (Bağış)
```
modules/donations/
  domain/
    donation.entity.ts
    campaign.entity.ts
  infrastructure/
    donations.repository.ts
    payment-gateway.ts
  application/
    donations.service.ts
    dto/
      create-donation.dto.ts
      campaign.dto.ts
  presentation/
    donations.controller.ts
  test/
  donations.module.ts
```

## 9. **notifications** (Bildirim)
```
modules/notifications/
  domain/
    notification.entity.ts
  infrastructure/
    notification.repository.ts
    push.service.ts
    sms.service.ts
  application/
    notification.service.ts
    dto/
      send-notification.dto.ts
  presentation/
    notifications.controller.ts
  test/
  notifications.module.ts
```

## 10. **moderation** (Moderasyon)
```
modules/moderation/
  domain/
    moderation-log.entity.ts
    report.entity.ts
  infrastructure/
    moderation.repository.ts
  application/
    moderation.service.ts
    dto/
      moderate-request.dto.ts
  presentation/
    moderation.controller.ts
  test/
  moderation.module.ts
```

## 11. **admin** (Yönetici Paneli)
```
modules/admin/
  domain/
    admin-activity.entity.ts
  infrastructure/
    admin.repository.ts
    analytics.service.ts
  application/
    admin.service.ts
    dto/
      broadcast-alert.dto.ts
  presentation/
    admin.controller.ts
  test/
  admin.module.ts
```

## 12. **monitoring** (Sağlık ve Loglama)
```
modules/monitoring/
  domain/
    health-status.entity.ts
    app-log.entity.ts
  infrastructure/
    monitoring.repository.ts
    prometheus.service.ts
  application/
    monitoring.service.ts
  presentation/
    monitoring.controller.ts
  test/
  monitoring.module.ts
```

## 13. **localization** (Çoklu Dil)
```
modules/localization/
  domain/
    translation.entity.ts
  infrastructure/
    localization.repository.ts
  application/
    localization.service.ts
    dto/
      translation.dto.ts
  presentation/
    localization.controller.ts
  test/
  localization.module.ts
```

## 14. **crisis** (Kriz Modu)
```
modules/crisis/
  domain/
    crisis-event.entity.ts
  infrastructure/
    crisis.repository.ts
  application/
    crisis.service.ts
    dto/
      sos.dto.ts
      offline-info.dto.ts
  presentation/
    crisis.controller.ts
  test/
  crisis.module.ts
```

---

## Ortak: **shared**, **config**, **main**

```
shared/
  guards/
  decorators/
  filters/
  logger/
  middlewares/
  utils/
  constants/
config/
  configuration.ts
  env/
    .env.dev
    .env.prod
main.ts
app.module.ts
```

---

**Notlar:**
- Her modülün application/domain/infrastructure/presentation/test katmanları ayrı klasörde tutulur.
- DTO’lar, entity ve servisler kendi modülünde izole edilir.
- Testler (unit/integration) her modül altındadır.
- Tüm ortak sınıflar ve yardımcılar shared altında tutulur.
- Konfigürasyonlar config/ altında merkezi olarak yönetilir.
- Gerektiğinde GraphQL için resolver.ts dosyaları da presentation/ altına eklenebilir.

---

Bu yapı, kodun sürdürülebilir, ölçeklenebilir, test edilebilir ve güvenli olmasını sağlar.  
Her modül için örnek dosya içerikleri veya Flutter (mobil) yapısı da istenirse eklenebilir.