# Tam Kapsamlı Afet Yönetim Sistemi Backend için Flutter Entegrasyonu – Örnek Yapı ve Kodlar

Aşağıda, profesyonel bir **Flutter istemcisinin** tam kapsamlı bir Afet Yönetim Sistemi (NestJS/TypeORM backend gibi) ile entegre olması için dosya yapısı, model, servis, ekran ve widget örnekleri sunulmuştur.  
Her modül için benzer yapı izlenerek, sürdürülebilir ve ölçeklenebilir bir mobil uygulama inşa edilebilir.

---

## Flutter Dosya Yapısı (Önerilen)

```
lib/
  models/
    user.dart
    alert.dart
    shelter.dart
    help_request.dart
    donation.dart
    ai_message.dart
  services/
    api_service.dart
    auth_service.dart
    notification_service.dart
    localization_service.dart
    offline_cache.dart
  providers/
    auth_provider.dart
    alerts_provider.dart
    map_provider.dart
    community_provider.dart
    ai_provider.dart
  screens/
    login_screen.dart
    dashboard_screen.dart
    alerts_screen.dart
    map_screen.dart
    help_screen.dart
    donate_screen.dart
    ai_bot_screen.dart
    profile_screen.dart
    crisis_mode_screen.dart
  widgets/
    alert_card.dart
    shelter_marker.dart
    help_request_card.dart
    donation_card.dart
    ai_chat_bubble.dart
    error_dialog.dart
  main.dart
```

---

## 1. Model Örneği (`models/alert.dart`)
```dart
class Alert {
  final String id;
  final String type;
  final String title;
  final String description;
  final double latitude;
  final double longitude;
  final String riskLevel;
  final String createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  factory Alert.fromJson(Map<String, dynamic> json) => Alert(
    id: json['id'],
    type: json['type'],
    title: json['title'],
    description: json['description'],
    latitude: json['location']['coordinates'][1],
    longitude: json['location']['coordinates'][0],
    riskLevel: json['risk_level'],
    createdAt: json['created_at'],
  );
}
```

---

## 2. Servis Örneği (`services/api_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/alert.dart';

class ApiService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<Alert>> fetchAlerts(String token) async {
    final response = await http.get(
      Uri.parse("$baseUrl/alerts"),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => Alert.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load alerts');
    }
  }

  // Benzer şekilde map, help, donation, AI vb. endpointler eklenir.
}
```

---

## 3. Provider Örneği (`providers/alerts_provider.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';
import '../services/api_service.dart';

class AlertsProvider with ChangeNotifier {
  final ApiService apiService;
  final String token;

  AlertsProvider(this.apiService, this.token);

  List<Alert> _alerts = [];
  bool _loading = false;
  String? _error;

  List<Alert> get alerts => _alerts;
  bool get loading => _loading;
  String? get error => _error;

  Future<void> loadAlerts() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      _alerts = await apiService.fetchAlerts(token);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }
}
```

---

## 4. Ekran Örneği (`screens/alerts_screen.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/alerts_provider.dart';
import '../widgets/alert_card.dart';

class AlertsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AlertsProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Afet Uyarıları")),
      body: provider.loading
          ? Center(child: CircularProgressIndicator())
          : provider.error != null
            ? Center(child: Text("Hata: ${provider.error}"))
            : ListView.builder(
                itemCount: provider.alerts.length,
                itemBuilder: (context, i) =>
                    AlertCard(alert: provider.alerts[i]),
              ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => provider.loadAlerts(),
        child: Icon(Icons.refresh),
      ),
    );
  }
}
```

---

## 5. Widget Örneği (`widgets/alert_card.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';

class AlertCard extends StatelessWidget {
  final Alert alert;
  const AlertCard({Key? key, required this.alert}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: alert.riskLevel == "high"
          ? Colors.red[100]
          : alert.riskLevel == "medium"
              ? Colors.orange[100]
              : Colors.green[100],
      child: ListTile(
        title: Text(alert.title),
        subtitle: Text(alert.description),
        trailing: Text(alert.riskLevel.toUpperCase()),
      ),
    );
  }
}
```

---

## 6. Auth Servisi ve Kullanımı (`services/auth_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  final String baseUrl = "https://api.afetapp.com";

  Future<String> login(String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/auth/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      return data['access_token'];
    } else {
      throw Exception('Login failed');
    }
  }
}
```

---

## 7. Offline ve Kriz Modu için Destek (`services/offline_cache.dart`)
```dart
import 'package:hive/hive.dart';
import '../models/alert.dart';

class OfflineCache {
  static Future<void> cacheAlerts(List<Alert> alerts) async {
    final box = await Hive.openBox('alerts');
    await box.put('list', alerts.map((a) => a.toJson()).toList());
  }

  static Future<List<Alert>> getCachedAlerts() async {
    final box = await Hive.openBox('alerts');
    final List? data = box.get('list');
    if (data == null) return [];
    return data.map((e) => Alert.fromJson(e)).toList();
  }
}
```

---

## 8. Ana Dosya (`main.dart`) – Temel State Management ile
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'providers/alerts_provider.dart';
import 'screens/alerts_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String demoToken = "YOUR_JWT_TOKEN";

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AlertsProvider(ApiService(), demoToken)..loadAlerts(),
        ),
        // Diğer providerlar...
      ],
      child: MaterialApp(
        title: 'Afet App',
        home: AlertsScreen(),
      ),
    );
  }
}
```

---

## Notlar

- **Her modül için (yardım, harita, bağış, AI, bildirim vb.)** benzer model/service/provider/screen/widget yapısı kullanılır.
- **JWT ile güvenli istek:** Tüm endpointlerde Authorization header’ı kullanılır.
- **Offline cache:** Hive, SQLite veya benzeri ile kolayca eklenebilir.
- **Çoklu dil:** localization_service.dart ile sağlanır.
- **Kriz/enerji modu:** provider ile tema/değer değiştirme ve offline çalışma örnekleri eklenebilir.
- **Gerçek-time notifications:** Firebase Messaging ile entegre edilebilir.
- **Test:** Widget ve provider testleri için Flutter test altyapısı önerilir.
- **Hatalar için ortak error_dialog.dart widget’ı kullanılabilir.

---

**Daha detaylı bir modül veya tam Flutter-backend uçtan uca örneği ister misiniz?**