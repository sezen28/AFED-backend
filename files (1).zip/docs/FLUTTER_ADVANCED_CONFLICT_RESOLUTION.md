# Flutter – Advanced Offline-First Conflict Çözüm Kodu (Uçtan Uca Örnek)

Aşağıda, Flutter uygulamasında **offline-first** mimaride “advanced conflict resolution” (ileri seviye çakışma çözümü) için uçtan uca örnek kodlar yer almaktadır.  
Senaryo: Kullanıcı offline iken bir kaydı (ör: yardım talebi) değiştirir. İnternete bağlanınca, aynı kayıt sunucuda da değişmişse, uygulama çakışmayı algılar ve kullanıcıya seçenek sunar.

---

## 1. Backend: Kayıtların Versiyonunu ve Son Güncellenme Zamanını Tutmak

```typescript name=src/modules/community/domain/help-request.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn } from 'typeorm';

@Entity()
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  description: string;

  @Column()
  status: string;

  @Column({ default: 1 })
  version: number;

  @UpdateDateColumn()
  updated_at: Date;
}
```

Her güncellemede, backend version ve updated_at alanını artırır.

---

## 2. Flutter: Local Model ve Conflict Data Yapısı

```dart name=lib/models/help_request.dart
class HelpRequest {
  final String id;
  final String description;
  final String status;
  final int version;
  final DateTime updatedAt;

  HelpRequest({
    required this.id,
    required this.description,
    required this.status,
    required this.version,
    required this.updatedAt,
  });

  factory HelpRequest.fromJson(Map<String, dynamic> json) => HelpRequest(
        id: json['id'],
        description: json['description'],
        status: json['status'],
        version: json['version'],
        updatedAt: DateTime.parse(json['updated_at']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'description': description,
        'status': status,
        'version': version,
        'updated_at': updatedAt.toIso8601String(),
      };
}
```

---

## 3. Local'den Sync Ederken Conflict Kontrolü

```dart name=lib/services/sync_service.dart
import '../models/help_request.dart';
import 'api_service.dart';

class SyncService {
  final ApiService apiService;
  SyncService(this.apiService);

  /// Localde değişmiş kayıtları sunucuya göndermeden önce version/timestamp kontrolü
  Future<SyncResult> syncHelpRequest(HelpRequest local) async {
    // 1. Sunucudan güncel veriyi al
    final remote = await apiService.fetchHelpRequestById(local.id);

    if (remote.version == local.version) {
      // Çakışma yok, local değişikliği push et
      await apiService.updateHelpRequest(local);
      return SyncResult.success;
    } else if (remote.updatedAt.isAfter(local.updatedAt)) {
      // Sunucudaki daha yeni, conflict var
      return SyncResult.conflict(local: local, remote: remote);
    } else {
      // Local daha yeni ama version çakışıyor, yine conflict
      return SyncResult.conflict(local: local, remote: remote);
    }
  }
}

/// Sync sonucu veri yapısı
class SyncResult {
  final HelpRequest? local;
  final HelpRequest? remote;
  final bool isConflict;
  final bool isSuccess;

  SyncResult.conflict({required this.local, required this.remote})
      : isConflict = true,
        isSuccess = false;

  SyncResult.success()
      : isSuccess = true,
        isConflict = false,
        local = null,
        remote = null;
}
```

---

## 4. Conflict UI: Kullanıcıya Farkları Göster ve Seçim Yaptır

```dart name=lib/widgets/help_request_conflict_dialog.dart
import 'package:flutter/material.dart';
import '../models/help_request.dart';

class HelpRequestConflictDialog extends StatelessWidget {
  final HelpRequest local;
  final HelpRequest remote;
  final void Function(HelpRequest resolved) onResolved;

  const HelpRequestConflictDialog({
    required this.local,
    required this.remote,
    required this.onResolved,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Çakışma Tespit Edildi"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Aynı yardım talebinde hem siz hem sistemde değişiklik var."),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: Text("Sizinki:", style: TextStyle(fontWeight: FontWeight.bold))),
              Expanded(child: Text("Sunucu:", style: TextStyle(fontWeight: FontWeight.bold))),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.description)),
              Expanded(child: Text(remote.description)),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.status)),
              Expanded(child: Text(remote.status)),
            ],
          ),
          SizedBox(height: 16),
          Text("Hangisini saklamak istersiniz?"),
        ],
      ),
      actions: [
        TextButton(
          child: Text("Benimki"),
          onPressed: () => onResolved(local),
        ),
        TextButton(
          child: Text("Sunucudaki"),
          onPressed: () => onResolved(remote),
        ),
        // İsteğe bağlı: birleştirerek düzenleme için başka bir seçenek eklenebilir
      ],
    );
  }
}
```

---

## 5. Kullanıcı Seçimine Göre Sync Devamı

```dart name=lib/screens/help_sync_screen.dart
import 'package:flutter/material.dart';
import '../models/help_request.dart';
import '../services/sync_service.dart';
import '../widgets/help_request_conflict_dialog.dart';

Future<void> syncAndResolve(BuildContext context, HelpRequest local, SyncService syncService) async {
  final result = await syncService.syncHelpRequest(local);
  if (result.isConflict) {
    // Çakışma varsa kullanıcıdan seçim iste
    showDialog(
      context: context,
      builder: (_) => HelpRequestConflictDialog(
        local: result.local!,
        remote: result.remote!,
        onResolved: (resolved) async {
          Navigator.of(context).pop();
          await syncService.apiService.updateHelpRequest(resolved);
          // Local cache'i de resolved ile güncelle
        },
      ),
    );
  } else if (result.isSuccess) {
    // Sync başarılı, cache güncelle
  }
}
```

---

## 6. Backend: API'de Conflict Yanıtı (Opsiyonel)

```typescript name=src/modules/community/presentation/help-request.controller.ts
import { Controller, Put, Body, Param, ConflictException } from '@nestjs/common';
import { HelpRequestService } from '../application/help-request.service';

@Controller('help-request')
export class HelpRequestController {
  constructor(private readonly service: HelpRequestService) {}

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: any,
  ) {
    const current = await this.service.findById(id);
    if (body.version !== current.version) {
      throw new ConflictException({
        message: 'Versiyon çakışması',
        server: current,
      });
    }
    return this.service.updateHelpRequest(id, body);
  }
}
```

---

## 7. Ekstra: “Birleştir” (Merge) Seçeneği için UI ve Fonksiyon

Kullanıcı isterse local ve remote verileri birleştirip yeni bir kayıt hazırlayabilir.  
Örneğin, local değişiklikte sadece açıklama değişmişse, diğer alanlar sunucudakiyle birleştirilebilir.

```dart name=lib/widgets/help_request_conflict_dialog.dart
// ... önceki kodun altında
TextButton(
  child: Text("Birleştir"),
  onPressed: () {
    final merged = HelpRequest(
      id: local.id,
      description: local.description + "\n---\n" + remote.description,
      status: local.status == remote.status ? local.status : "${local.status} / ${remote.status}",
      version: remote.version + 1,
      updatedAt: DateTime.now(),
    );
    onResolved(merged);
  },
),
```

---

## 8. Notlar

- Her veri için (yardım, profil, donation vb.) benzer conflict çözümü uygulanabilir.
- Otomatik çözüm istenirse `updatedAt` daha yeni olanı tercih etmek gibi stratejiler eklenebilir.
- Kullanıcıya çakışma bildiren banner veya bildirim gösterilebilir.

---

**Daha ileri:**
- Otomatik birleştirme (otomated merge), conflict durumlarını loglama, toplu sync için benzer dialoglar, vs.

---