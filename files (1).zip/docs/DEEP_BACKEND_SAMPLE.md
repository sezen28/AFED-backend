# Tam Kapsamlı Afet Yönetim Sistemi – Her Modül İçin Derinlemesine Backend Örnekleri

Aşağıda, **her ana modül için kurumsal düzeyde backend dosya içerikleri**, ileri güvenlik, domain-driven design, test kolaylığı ve genişletilebilirlik prensipleriyle birlikte sunulmuştur.

---

## 1. AUTH MODULE

### `domain/auth-session.entity.ts`
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class AuthSession {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  user_id: string;

  @Column()
  refresh_token: string;

  @Column()
  ip_address: string;

  @Column()
  user_agent: string;

  @CreateDateColumn()
  created_at: Date;

  @Column({ default: false })
  revoked: boolean;
}
```

### `application/auth.service.ts`
```typescript
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UsersService } from '../../users/application/users.service';
import { JwtService } from '@nestjs/jwt';
import { compare } from 'bcrypt';
import { AuthSession } from '../domain/auth-session.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    @InjectRepository(AuthSession)
    private readonly sessionRepo: Repository<AuthSession>,
  ) {}

  async validateUser(email: string, password: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user || !(await compare(password, user.password_hash))) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return user;
  }

  async login(user: any, ip: string, agent: string) {
    const payload = { sub: user.id, role: user.role };
    const access_token = this.jwtService.sign(payload, { expiresIn: '15m' });
    const refresh_token = this.jwtService.sign(payload, { expiresIn: '7d' });

    await this.sessionRepo.save(this.sessionRepo.create({
      user_id: user.id,
      refresh_token,
      ip_address: ip,
      user_agent: agent,
    }));

    return { access_token, refresh_token };
  }

  async revokeSession(refresh_token: string) {
    const session = await this.sessionRepo.findOne({ where: { refresh_token } });
    if (session) {
      session.revoked = true;
      await this.sessionRepo.save(session);
    }
  }
}
```

### `presentation/auth.controller.ts`
```typescript
import { Controller, Post, Body, Req } from '@nestjs/common';
import { AuthService } from '../application/auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() { email, password }: { email: string, password: string }, @Req()