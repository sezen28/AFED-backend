# Tam Kapsamlı Flutter Afet Yönetimi Uygulaması – Dosya Yapısı ve Örnek Kodlar

Aşağıda, profesyonel, modüler ve sürdürülebilir bir Flutter afet yönetimi uygulaması için tam kapsamlı dosya iskeleti ve temel örnek kodlar bulacaksınız.  
Her modül (uyarılar, harita/barınak, topluluk/yardım, bağış, AI, kullanıcı, bildirim, offline cache, kriz modu) için model, servis, provider, ekran ve widget örnekleri içerir.

---

## 1. Dosya Yapısı

```
lib/
  models/
    alert.dart
    user.dart
    shelter.dart
    help_request.dart
    donation.dart
    ai_message.dart
  services/
    api_service.dart
    auth_service.dart
    offline_cache.dart
    notification_service.dart
    sync_service.dart
  providers/
    auth_provider.dart
    alerts_provider.dart
    map_provider.dart
    community_provider.dart
    donations_provider.dart
    ai_provider.dart
  screens/
    login_screen.dart
    dashboard_screen.dart
    alerts_screen.dart
    map_screen.dart
    help_screen.dart
    donate_screen.dart
    ai_bot_screen.dart
    profile_screen.dart
    crisis_mode_screen.dart
  widgets/
    alert_card.dart
    shelter_marker.dart
    help_request_card.dart
    donation_card.dart
    ai_chat_bubble.dart
    error_dialog.dart
  queue/
    help_queue.dart
  main.dart
```

---

## 2. Model Örneği (`models/alert.dart`)
```dart
class Alert {
  final String id;
  final String type;
  final String title;
  final String description;
  final double latitude;
  final double longitude;
  final String riskLevel;
  final String createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  factory Alert.fromJson(Map<String, dynamic> json) => Alert(
        id: json['id'],
        type: json['type'],
        title: json['title'],
        description: json['description'],
        latitude: json['location']['coordinates'][1],
        longitude: json['location']['coordinates'][0],
        riskLevel: json['risk_level'],
        createdAt: json['created_at'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'description': description,
        'location': {
          'coordinates': [longitude, latitude]
        },
        'risk_level': riskLevel,
        'created_at': createdAt,
      };
}
```

---

## 3. Servis Örneği (`services/api_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/alert.dart';

class ApiService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<Alert>> fetchAlerts(String token) async {
    final response = await http.get(
      Uri.parse("$baseUrl/alerts"),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => Alert.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load alerts');
    }
  }

  // Diğer veri türleri için benzer endpointler eklenir.
}
```

---

## 4. Provider Örneği (`providers/alerts_provider.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';
import '../services/api_service.dart';
import '../services/offline_cache.dart';
import 'dart:io';

class AlertsProvider with ChangeNotifier {
  final ApiService apiService;
  final String token;

  List<Alert> _alerts = [];
  bool _loading = false;
  String? _error;

  List<Alert> get alerts => _alerts;
  bool get loading => _loading;
  String? get error => _error;

  AlertsProvider(this.apiService, this.token);

  Future<void> loadAlerts({bool forceOnline = false}) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      bool isOnline = false;
      try {
        final result = await InternetAddress.lookup('google.com');
        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) isOnline = true;
      } catch (_) {}
      if (isOnline || forceOnline) {
        _alerts = await apiService.fetchAlerts(token);
        await OfflineCache.cacheAlerts(_alerts);
        await OfflineCache.setLastUpdated(DateTime.now());
      } else {
        _alerts = await OfflineCache.getCachedAlerts();
      }
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }
}
```

---

## 5. Offline Cache Servisi (`services/offline_cache.dart`)
```dart
import 'package:hive/hive.dart';
import '../models/alert.dart';

class OfflineCache {
  static const String alertsKey = 'alerts';

  static Future<void> cacheAlerts(List<Alert> alerts) async {
    final box = await Hive.openBox<Alert>(alertsKey);
    await box.clear();
    await box.addAll(alerts);
  }

  static Future<List<Alert>> getCachedAlerts() async {
    final box = await Hive.openBox<Alert>(alertsKey);
    return box.values.toList();
  }

  static Future<DateTime?> getLastUpdated() async {
    final box = await Hive.openBox('cache_meta');
    return box.get('alerts_last_updated');
  }

  static Future<void> setLastUpdated(DateTime dateTime) async {
    final box = await Hive.openBox('cache_meta');
    await box.put('alerts_last_updated', dateTime);
  }
}
```

---

## 6. Ekran Örneği (`screens/alerts_screen.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/alerts_provider.dart';
import '../widgets/alert_card.dart';
import '../services/offline_cache.dart';

class AlertsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AlertsProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Afet Uyarıları")),
      body: provider.loading
          ? Center(child: CircularProgressIndicator())
          : provider.error != null
              ? Center(child: Text("Hata: ${provider.error}"))
              : Column(
                  children: [
                    FutureBuilder<DateTime?>(
                      future: OfflineCache.getLastUpdated(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData && snapshot.data != null) {
                          return Padding(
                            padding: EdgeInsets.all(8),
                            child: Text(
                              "Veri güncelleme zamanı: ${snapshot.data!.toLocal()}",
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          );
                        }
                        return SizedBox.shrink();
                      },
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: provider.alerts.length,
                        itemBuilder: (context, i) =>
                            AlertCard(alert: provider.alerts[i]),
                      ),
                    ),
                  ],
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => provider.loadAlerts(),
        child: Icon(Icons.refresh),
      ),
    );
  }
}
```

---

## 7. Widget Örneği (`widgets/alert_card.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';

class AlertCard extends StatelessWidget {
  final Alert alert;
  const AlertCard({Key? key, required this.alert}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: alert.riskLevel == "high"
          ? Colors.red[100]
          : alert.riskLevel == "medium"
              ? Colors.orange[100]
              : Colors.green[100],
      child: ListTile(
        title: Text(alert.title),
        subtitle: Text(alert.description),
        trailing: Text(alert.riskLevel.toUpperCase()),
      ),
    );
  }
}
```

---

## 8. Auth Servisi ve Kullanımı (`services/auth_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  final String baseUrl = "https://api.afetapp.com";

  Future<String> login(String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/auth/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      return data['access_token'];
    } else {
      throw Exception('Login failed');
    }
  }
}
```

---

## 9. Ana Dosya (`main.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'providers/alerts_provider.dart';
import 'screens/alerts_screen.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter(); // Hive başlat
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String demoToken = "YOUR_JWT_TOKEN";

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AlertsProvider(ApiService(), demoToken)..loadAlerts(),
        ),
        // Diğer providerlar...
      ],
      child: MaterialApp(
        title: 'Afet App',
        home: AlertsScreen(),
      ),
    );
  }
}
```

---

## 10. Notlar ve Genişletme

- Her modül (yardım, barınak, bağış, AI, bildirim, offline) için aynı yapı tekrarlanır.
- Queue (örn: yardım talebi), sync_service, background sync, conflict çözümü, şifreli cache modülleri eklenebilir.
- Çoklu dil, offline harita, kriz/enerji tasarruf modu ve bildirimler kolayca entegre edilebilir.
- Gelişmiş test ve monitoring altyapısı eklenebilir.
- Detaylı modül veya ekran kodu için ayrıca istekte bulunabilirsiniz.

---