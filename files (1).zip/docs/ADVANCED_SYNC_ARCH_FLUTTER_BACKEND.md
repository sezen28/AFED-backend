# Gelişkin Senkronizasyon Mimarisi – Afet Yönetimi (Flutter ve Backend)

Bu dokümanda, offline-first çalışan bir afet uygulaması için **en gelişkin senkronizasyon mimarisi** sunulmuştur. Amaç; veri tutarlılığı, hız, çakışma yönetimi ve enerji verimliliği sağlar.

---

## 1. Temel Senkronizasyon Senaryoları

- **Delta Sync:** Sadece değişen/veri güncellenen kayıtlar alınır/gönderilir.
- **Bidirectional Sync:** Hem localden sunucuya hem sunucudan locale farklılıklar eşzamanlı aktarılır.
- **Conflict Handling:** Çakışma anında otomatik veya kullanıcıya sorarak çözüm.
- **Queue ve Status:** Her local değişiklik bir kuyrukta “pending”, “syncing”, “synced”, “conflict”, “failed” olarak izlenir.
- **Batch Sync:** Çoklu kaydı tek API çağrısıyla senkronize etme.
- **Arka Plan/Push Tetikleme:** Sync işlemi hem periyodik, hem push notification ile hem de uygulama açılışında tetiklenir.
- **Enerji Modu:** Sync sıklığı ve batch boyutu enerji moduna göre dinamik değişir.

---

## 2. Backend (NestJS/TypeORM) – Önerilen Delta/Bulk API

```typescript name=src/modules/help/presentation/help-request.controller.ts
import { Controller, Post, Body, Query, UseGuards } from '@nestjs/common';
import { HelpRequestService } from '../application/help-request.service';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';

@Controller('help-requests')
@UseGuards(JwtAuthGuard)
export class HelpRequestController {
  constructor(private readonly service: HelpRequestService) {}

  // Delta endpoint: updated_at > clientLastSync
  @Post('delta')
  async delta(
    @Body() body: { lastSync: string, ids?: string[] }
  ) {
    return this.service.deltaHelpRequests(new Date(body.lastSync), body.ids);
  }

  // Bulk upsert endpoint: çoklu kayıt update/insert
  @Post('batch-upsert')
  async batchUpsert(
    @Body() body: { requests: any[] }
  ) {
    return this.service.batchUpsert(body.requests);
  }
}
```
**Services içeriği:**
- `deltaHelpRequests(lastSync, ids)` → Sadece güncellenen veya eklenen kayıtları döner.
- `batchUpsert(requests)` → Kayıtları tek tek version ile kontrol eder, çakışmaları ve başarılı olanları ayrı döner.

---

## 3. Gelişkin Flutter SyncService

```dart name=lib/services/advanced_sync_service.dart
import 'dart:io';
import '../queue/help_queue.dart';
import '../models/help_request.dart';
import '../services/help_service.dart';
import '../services/offline_cache.dart';

enum SyncStatus { pending, syncing, synced, conflict, failed }

class SyncEntry {
  HelpRequest request;
  SyncStatus status;
  String? conflictReason;
  HelpRequest? serverCopy;

  SyncEntry(this.request, this.status, {this.conflictReason, this.serverCopy});
}

class AdvancedSyncService {
  final HelpService helpService;
  final String token;

  AdvancedSyncService(this.helpService, this.token);

  /// Ana sync fonksiyonu
  Future<void> syncAll() async {
    if (!await _isOnline()) return;

    // 1. Sunucudan delta çek (sunucuda değişen kayıtlar)
    DateTime? lastSync = await OfflineCache.getLastUpdated();
    final serverDeltas = await helpService.fetchDeltaHelpRequests(token, lastSync: lastSync);

    // 2. Localdeki kayıtları güncelle
    await OfflineCache.mergeDeltas(serverDeltas);

    // 3. Localde pending/syncing olan queue’yu oku
    final List<HelpRequest> toSync = await HelpQueue.getQueue();
    if (toSync.isEmpty) return;

    // 4. Batch upsert API ile toplu gönderim
    final batchResult = await helpService.batchUpsertHelpRequests(token, toSync);

    // 5. Sonuca göre queue güncelle: synced → silinir, conflict → status update edilir
    for (final result in batchResult) {
      if (result['status'] == 'synced') {
        await HelpQueue.removeFromQueueById(result['id']);
      } else if (result['status'] == 'conflict') {
        await HelpQueue.markAsConflict(result['id'], result['serverCopy']);
        // Uygulamada conflict dialog açılabilir
      }
    }
    // 6. Son sync zamanı kaydedilir
    await OfflineCache.setLastUpdated(DateTime.now());
  }

  Future<bool> _isOnline() async {
    try {
      final res = await InternetAddress.lookup('google.com');
      return res.isNotEmpty;
    } catch (_) {
      return false;
    }
  }
}
```
- **mergeDeltas**: localde olmayanı ekler, güncelleneni günceller.
- **batchUpsertHelpRequests**: batch ile API’ye gönderir, dönen sonucu işler.
- **markAsConflict**: queue’da ilgili kaydın status’unu conflict yapar, server versiyonunu saklar.

---

## 4. HelpService – Delta ve Batch Upsert Fonksiyonları

```dart name=lib/services/help_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/help_request.dart';

class HelpService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<HelpRequest>> fetchDeltaHelpRequests(String token, {DateTime? lastSync}) async {
    final response = await http.post(
      Uri.parse("$baseUrl/help-requests/delta"),
      headers: {"Authorization": "Bearer $token", "Content-Type": "application/json"},
      body: jsonEncode({"lastSync": lastSync?.toUtc().toIso8601String()}),
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => HelpRequest.fromJson(json)).toList();
    } else {
      throw Exception('Failed to delta fetch');
    }
  }

  Future<List<Map<String, dynamic>>> batchUpsertHelpRequests(String token, List<HelpRequest> requests) async {
    final response = await http.post(
      Uri.parse("$baseUrl/help-requests/batch-upsert"),
      headers: {"Authorization": "Bearer $token", "Content-Type": "application/json"},
      body: jsonEncode({"requests": requests.map((e) => e.toJson()).toList()}),
    );
    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(json.decode(response.body));
    } else {
      throw Exception('Failed to batch upsert');
    }
  }
}
```

---

## 5. Queue Yönetimi ve Conflict

```dart name=lib/queue/help_queue.dart
// ... diğer fonksiyonlara ek olarak

static Future<void> markAsConflict(String id, HelpRequest serverCopy) async {
  final box = await Hive.openBox<HelpRequest>(boxKey);
  final idx = box.values.toList().indexWhere((e) => e.id == id);
  if (idx != -1) {
    // Status’u güncelle, serverCopy’yi de custom field ile sakla (ör: metadata kutusu)
    await box.putAt(idx, box.getAt(idx)!.copyWith(status: 'conflict'));
    // serverCopy’yi ayrı bir kutuda veya metadata’da saklayabilirsiniz
  }
}

static Future<void> removeFromQueueById(String id) async {
  final box = await Hive.openBox<HelpRequest>(boxKey);
  final idx = box.values.toList().indexWhere((e) => e.id == id);
  if (idx != -1) await box.deleteAt(idx);
}
```

---

## 6. Enerji Modu ile Sync Parametreleri

```dart name=lib/providers/crisis_provider.dart
// ... önceki kodun üstüne ek
int get syncIntervalMinutes => _energySaving ? 60 : 10;
int get syncBatchSize => _energySaving ? 5 : 20;
```
- SyncService, bu parametrelerle batch ve periyodik sync ayarını dinamik belirler.

---

## 7. Push Notification veya Background ile Sync Tetikleme

```dart name=lib/services/notification_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import '../services/advanced_sync_service.dart';

void setupNotifications(AdvancedSyncService syncService) {
  Firebase