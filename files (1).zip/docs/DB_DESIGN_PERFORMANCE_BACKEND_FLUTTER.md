# Performanslı Veritabanı Tasarımı – Backend (NestJS/TypeORM) & Flutter

Aşağıda, afet yönetimi gibi büyük ölçekli bir sistem için **performanslı veritabanı şeması** ve hem backend (NestJS/TypeORM) hem de Flutter için verimli entegrasyonun temel noktaları özetlenmiştir.

---

## 1. Backend İçin Performanslı Veritabanı Tasarımı

### a) Genel İlkeler

- **Normalize edin, ancak okuma ağırlıklı sistemlerde gerekli yerlerde denormalizasyon kullanın** (örn. rapor/analitik için summary tablolar).
- **Sık aranan alanlara index ekleyin.**
- **Geo verileri için spatial index (PostGIS/geometry) kullanın.**
- **UUID veya Snowflake ID gibi dağıtık benzersiz ID’ler kullanın.**
- **Soft delete (is_active, deleted_at) ile silinenleri saklayın.**
- **İlişkili büyük verileri (örn. loglar, mesajlar) ayrı tablolarda tutun.**
- **Veri bütünlüğü için foreign key ve unique constraint’ler kullanın.**

### b) Örnek Entity ve Index Tasarımı (PostgreSQL + TypeORM)

```typescript name=src/modules/alerts/domain/alert.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, Index } from 'typeorm';

@Entity()
@Index(['type', 'risk_level']) // Sık filtrelenen alanlar
export class Alert {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  @Index() // Tekil arama için
  type: string;

  @Column()
  title: string;

  @Column('text')
  description: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  @Index({ spatial: true })
  location: string;

  @Column()
  @Index()
  risk_level: string;

  @Column({ default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

**Ek:**  
- Yardım talepleri, kullanıcı, barınak, bağış gibi tablolar için de benzer şekilde index’li ve iyi ilişkili şema kurulur.
- Büyük veri (log, medya) için ayrı storage (S3, blob) önerilir.

---

## 2. Flutter İçin Verimli Lokal DB (Offline/Sync)

### a) Küçük/Orta veri için: **Hive** (NoSQL, hızlı, mobil için ideal)
- JSON map ile native veri saklama, hızlı indexleme.
- Şifreli kutu desteği.
- Ekstra: SQLite/Isar ağır ilişkili veri için kullanılabilir.

### b) Model ve Indexleme
```dart name=lib/models/alert.dart
import 'package:hive/hive.dart';

part 'alert.g.dart';

@HiveType(typeId: 0)
class Alert extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String type;
  @HiveField(2)
  final String title;
  @HiveField(3)
  final String description;
  @HiveField(4)
  final double latitude;
  @HiveField(5)
  final double longitude;
  @HiveField(6)
  final String riskLevel;
  @HiveField(7)
  final String createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  // fromJson/toJson ekleyin...
}
```

### c) Performans için İpuçları
- Sık erişilen kutuları açık tutun, çok büyük veri için lazy loading kullanın.
- Aramalarda `box.values.where((a) => a.riskLevel == 'high')` gibi filtre kullanın.
- Büyük veri (örn. harita, medya) için path veya referans saklayın.

---

## 3. Senkronizasyon ve Data Management

- **Backend:** Her kaydın `updatedAt` ve `version` alanı olmalı (delta sync için).
- **Flutter:** Her veri kutusu için son sync zamanı tutulmalı.
- **Batch/Delta endpointler** ile sadece değişen kayıtlar çekilmeli.
- **Conflict çözüm mimarisi** kurulu olmalı (bkz: önceki conflict örnekleri).

---

## 4. Ekstra: Performans Testleri

- Backend’de tablo büyüdükçe index performansı için explain analyze ile sorgu testleri yapılmalı.
- Flutter’da büyük veri ile widget rebuild ve filter işlemleri test edilmeli.

---

**Detaylı bir tablo şeması ya da modül için uçtan uca veri modeli ister misiniz?**