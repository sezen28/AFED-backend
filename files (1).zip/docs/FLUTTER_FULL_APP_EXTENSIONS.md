# Flutter Afet Yönetimi Uygulaması – Queue, Sync, Background Sync, Conflict ve Şifreli Cache Modülleri

Aşağıda, tam kapsamlı bir afet uygulamasına offline-first, veri bütünlüğü ve güvenliği için şu gelişmiş modüller eklenmiştir:

- **Queue:** Offline veri girişi, otomatik kuyruklama  
- **SyncService:** Online olduğunda otomatik veya manuel veri senkronizasyonu  
- **Background Sync:** Uygulama kapalıyken arka planda sync işlemleri  
- **Conflict Resolution:** Çakışma durumunda veri birleştirme/seçim  
- **Şifreli Cache:** Hassas veriler için AES ile güvenli local saklama

---

## 1. Queue Modülü (`queue/help_queue.dart`)
```dart
import 'package:hive/hive.dart';
import '../models/help_request.dart';

class HelpQueue {
  static const String boxKey = 'help_queue';

  static Future<void> addToQueue(HelpRequest req) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.add(req);
  }

  static Future<List<HelpRequest>> getQueue() async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    return box.values.toList();
  }

  static Future<void> removeFromQueue(int index) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.deleteAt(index);
  }

  static Future<void> clearQueue() async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.clear();
  }
}
```

---

## 2. Sync Service (`services/sync_service.dart`)
```dart
import 'dart:io';
import '../queue/help_queue.dart';
import '../services/api_service.dart';
import '../models/help_request.dart';

class SyncService {
  final ApiService apiService;

  SyncService(this.apiService);

  Future<void> syncHelpRequests() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isEmpty) return; // Offline
      final queue = await HelpQueue.getQueue();
      for (var i = queue.length - 1; i >= 0; i--) {
        try {
          // Çakışma kontrolü için sunucudan güncel veri çek
          final remote = await apiService.fetchHelpRequestById(queue[i].id);
          if (remote == null || remote.version == queue[i].version) {
            await apiService.sendHelpRequest(queue[i]);
            await HelpQueue.removeFromQueue(i);
          } else {
            // Conflict tespit edildi, localde işaretle veya kullanıcıya aktar
            // (örn: conflict alanı ekleyip UI'da göster)
          }
        } catch (_) {
          // Sunucuya erişilemiyorsa sonraki sync'e bırak
        }
      }
    } catch (_) {}
  }
}
```

---

## 3. Background Sync (Workmanager ile) (`main.dart` ve `services/background_sync.dart`)
```dart
// pubspec.yaml: workmanager: ^0.5.2 ekleyin

// services/background_sync.dart
import 'package:workmanager/workmanager.dart';
import 'sync_service.dart';
import 'api_service.dart';

void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    // API Service ve Sync Service instance oluşturun
    final apiService = ApiService();
    final syncService = SyncService(apiService);
    await syncService.syncHelpRequests();
    return Future.value(true);
  });
}

// main.dart içinde
import 'package:workmanager/workmanager.dart';
import 'services/background_sync.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  Workmanager().registerPeriodicTask(
    "sync-task",
    "syncTask",
    frequency: Duration(hours: 1),
  );
  runApp(MyApp());
}
```

---

## 4. Conflict Çözümü (`widgets/help_request_conflict_dialog.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/help_request.dart';

class HelpRequestConflictDialog extends StatelessWidget {
  final HelpRequest local;
  final HelpRequest remote;
  final void Function(HelpRequest resolved) onResolved;

  const HelpRequestConflictDialog({
    required this.local,
    required this.remote,
    required this.onResolved,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Çakışma Tespit Edildi"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Aynı yardım talebinde hem siz hem sistemde değişiklik var."),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: Text("Sizinki:", style: TextStyle(fontWeight: FontWeight.bold))),
              Expanded(child: Text("Sunucu:", style: TextStyle(fontWeight: FontWeight.bold))),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.description)),
              Expanded(child: Text(remote.description)),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.status)),
              Expanded(child: Text(remote.status)),
            ],
          ),
          SizedBox(height: 16),
          Text("Hangisini saklamak istersiniz?"),
        ],
      ),
      actions: [
        TextButton(
          child: Text("Benimki"),
          onPressed: () => onResolved(local),
        ),
        TextButton(
          child: Text("Sunucudaki"),
          onPressed: () => onResolved(remote),
        ),
        TextButton(
          child: Text("Birleştir"),
          onPressed: () {
            final merged = HelpRequest(
              id: local.id,
              description: local.description + "\n---\n" + remote.description,
              status: local.status == remote.status
                  ? local.status
                  : "${local.status} / ${remote.status}",
              version: remote.version + 1,
              updatedAt: DateTime.now(),
            );
            onResolved(merged);
          },
        ),
      ],
    );
  }
}
```

---

## 5. Şifreli Cache (`services/secure_cache.dart`)
```dart
import 'package:hive/hive.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';

class SecureCache {
  static Future<List<int>> getEncryptionKey(String password) async {
    // Uygulamada güvenli şekilde saklanmalı!
    final key = sha256.convert(utf8.encode(password)).bytes;
    return key;
  }

  static Future<Box> openEncryptedBox(String boxName, List<int> key) async {
    return await Hive.openBox(boxName, encryptionCipher: HiveAesCipher(key));
  }

  static Future<void> putSecure(String boxName, String key, dynamic value, List<int> encKey) async {
    final box = await openEncryptedBox(boxName, encKey);
    await box.put(key, value);
  }

  static Future<dynamic> getSecure(String boxName, String key, List<int> encKey) async {
    final box = await openEncryptedBox(boxName, encKey);
    return box.get(key);
  }
}
```

---

## 6. Entegrasyon Notları

- **Queue:** Tüm offline yardım talepleri önce queue’ya eklenir, başarılı sync olunca silinir.
- **SyncService:** Hem manuel (kullanıcı isteğiyle) hem de background’da otomatik çalışabilir.
- **Conflict:** Sync sırasında çakışma çıkarsa, kullanıcıya seçenek sunan dialog açılır.
- **Background Sync:** Workmanager veya background_fetch ile otomatik sync tetiklenir.
- **Şifreli Cache:** Kullanıcıya ait veya hassas tüm veriler şifreli kutuda tutulur.
- **Her modül için aynı mimari kolayca genişletilebilir.**

---

**Dilerseniz, bir modül için tam örnek uçtan uca iş akışı veya test kodu da sunabilirim.**