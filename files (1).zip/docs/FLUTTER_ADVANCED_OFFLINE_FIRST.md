# Flutter için İleri Seviye Offline-First Mimari (Afet Yönetim Sistemi)

Bu doküman, tam kapsamlı bir afet yönetim mobil uygulamasında **ileri seviyede offline-first mimari**yi nasıl kurabileceğinizi gösterir.  
Amaç: Kullanıcı, internet bağlantısı olmadığında bile uygulamanın ana fonksiyonlarını (uyarılar, harita, yardım, bağış vb.) güvenli ve tutarlı şekilde kullanmaya devam edebilsin.

---

## 1. Temel Prensipler

- **Tüm önemli veriler local cache’de (Hive/SQLite) saklanır.**
- **Verinin güncelliği ve kaynağı (online/offline) her zaman kullanıcıya gösterilir.**
- **Kullanıcı veri girişi (yardım talebi vb.) offline modda yapılabilir, otomatik veya manuel sync ile sunucuya iletilir.**
- **Çakışma (conflict) ve veri bütünlüğü için her kayıt unique id ve timestamp ile tutulur.**
- **İlk açılışta minimum veri (ör: bilgi kütüphanesi, rehberler, barınaklar) preload edilir.**

---

## 2. Gelişmiş Offline-First Katmanları

### 2.1. Data Layer (Repository Pattern)
- **RemoteDataSource:** API üzerinden güncel veriyi getirir.
- **LocalDataSource:** Hive/SQLite ile offline veri okuma/yazma.
- **Repository:** Hem local hem remote data source’u yönetir, sync ve conflict çözümünü üstlenir.

### 2.2. Sync Servisi
- Ağ gelince local-değişiklikleri (ör: yeni yardım talebi) otomatik olarak sunucuya gönderir.
- Sync sırasında hata olursa tekrar dener veya kullanıcıya bildirir.
- Sync işlemleri arka planda (background fetch) veya uygulama açıldığında tetiklenir.

---

## 3. Örnek: Alerts için İleri Sync & Conflict Management

### 3.1. Repository (`repositories/alerts_repository.dart`)
```dart
class AlertsRepository {
  final ApiService apiService;
  final OfflineCache offlineCache;

  AlertsRepository(this.apiService, this.offlineCache);

  Future<List<Alert>> fetchAlerts({bool forceRemote = false}) async {
    try {
      if (forceRemote) throw Exception(); // Zorunlu online
      final cached = await offlineCache.getCachedAlerts();
      if (cached.isNotEmpty) return cached;
      throw Exception();
    } catch (_) {
      final online = await apiService.fetchAlerts();
      await offlineCache.cacheAlerts(online);
      return online;
    }
  }

  // Diğer modüller için benzer pattern uygulanır
}
```

### 3.2. Yardım Talebi için Offline Queue (`queue/help_queue.dart`)
```dart
import 'package:hive/hive.dart';
import '../models/help_request.dart';

class HelpQueue {
  static const String boxKey = 'help_queue';

  static Future<void> addToQueue(HelpRequest req) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.add(req);
  }

  static Future<List<HelpRequest>> getQueue() async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    return box.values.toList();
  }

  static Future<void> removeFromQueue(int index) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.deleteAt(index);
  }
}
```

### 3.3. Sync Servisi (`services/sync_service.dart`)
```dart
import 'dart:io';
import '../queue/help_queue.dart';
import '../services/api_service.dart';

class SyncService {
  final ApiService apiService;

  SyncService(this.apiService);

  Future<void> syncHelpRequests() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isEmpty) return;
      final queue = await HelpQueue.getQueue();
      for (var i = 0; i < queue.length; i++) {
        try {
          await apiService.sendHelpRequest(queue[i]);
          await HelpQueue.removeFromQueue(i);
        } catch (_) {
          // Sunucu erişilemiyorsa sonraki sync'e bırak
        }
      }
    } catch (_) {}
  }
}
```

### 3.4. Kullanıcıdan Veri Girişi (`help_screen.dart`)
```dart
import '../queue/help_queue.dart';
import '../services/sync_service.dart';

// ... formdan submit alınır
Future<void> submitHelpRequest(HelpRequest req, SyncService syncService) async {
  await HelpQueue.addToQueue(req); // Her durumda local queue'ya ekle
  await syncService.syncHelpRequests(); // Online ise hemen sync etmeye çalış
}
```

---

## 4. Veri Güncelliği ve Kaynağı UI'da Gösterimi

```dart
// Veri kaynağına göre banner veya icon göster
Widget buildAlertBanner(bool isOnline, DateTime? lastSync) {
  if (isOnline) {
    return Text("Online - En güncel veri", style: TextStyle(color: Colors.green));
  } else {
    return Text(
      "Offline - Son güncelleme: ${lastSync ?? 'Bilinmiyor'}",
      style: TextStyle(color: Colors.orange),
    );
  }
}
```

---

## 5. Conflict Çözümü

- Her local değişiklikte kayıt unique id (örn. uuid) ve timestamp ile tutulur.
- Sync sırasında sunucuya gönderilen verilerde timestamp ile çakışma kontrolü yapılır.
- Sunucu, aynı kaydın daha günceli varsa localdeki kaydı reddeder veya günceller.
- Kullanıcıya “Localde kaydınız güncel değil, güncellemek ister misiniz?” gibi seçenek sunulabilir.

---

## 6. Ekstra: Gelişmiş Özellikler

- **Background Sync:** Android/iOS background fetch veya periodic task ile otomatik sync.
- **Push ile Sync Tetikleme:** Sunucudan gelen push notification sync’i tetikleyebilir.
- **Şifreli Cache:** Kişisel veri için Hive’ın encrypted box özelliği kullanılabilir.
- **Veri Boyutu Yönetimi:** Çok eski veya büyük datalar otomatik silinir/arşivlenir.
- **Kapsamlı Test:** Offline/online geçiş, çakışma, veri kaybı testleri otomasyona alınır.

---

## 7. Backend Önerileri

- **Veri conflict çözümüne uygun endpointler** (örn. timestamp/etag ile update)
- **Toplu veri çekme ve delta güncellemeler** (sadece değişen kayıtlar)
- **Sync sırasında hata mesajları ve conflict kodları**

---

**Daha fazla örnek (offline harita, background sync, conflict testleri, şifreli cache) veya belirli bir modül için offline-first kodu ister misiniz?**