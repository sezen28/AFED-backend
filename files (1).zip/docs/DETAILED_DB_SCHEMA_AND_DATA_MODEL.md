# Detaylı Tablo Şeması ve Uçtan Uca Veri Modeli – Afet Yönetimi (Yardım Talebi Modülü Örneği)

Aşağıda, afet yönetimi sisteminde **yardım talebi (Help Request)** modülü için uçtan uca detaylı veritabanı şeması ve Flutter ile backend arasında veri modelinin tam örneği sunulmuştur.

---

## 1. ER Diyagramı ve Tablo Şeması

### Temel Tablo: **help_requests**
- Her yardım talebi bir kullanıcıya ve isteğe bağlı olarak bir barınağa/afete bağlanır.
- Konum, durum, öncelik, ilişkilendirilmiş dosyalar, loglar ve offline senkronizasyon için alanlar içerir.

| Alan Adı         | Tipi            | Açıklama                       | Özellikler            |
|------------------|-----------------|--------------------------------|-----------------------|
| id               | uuid            | Yardım talebi ID’si            | PK, unique            |
| user_id          | uuid            | Talep eden kullanıcı           | FK -> users(id)       |
| shelter_id       | uuid (null)     | İlgili barınak                 | FK -> shelters(id)    |
| disaster_id      | uuid (null)     | İlgili afet                    | FK -> disasters(id)   |
| description      | text            | Talep açıklama                 |                       |
| status           | varchar         | Durum (open, assigned, closed) | index                 |
| priority         | varchar         | Öncelik (low, med, high, crit) | index                 |
| location         | geometry(Point) | Koordinat                      | spatial index         |
| files            | text[]/jsonb    | İlişkili dosya URL’leri        |                       |
| created_at       | timestamptz     | Oluşturulma zamanı             | index                 |
| updated_at       | timestamptz     | Son güncelleme                 |                       |
| version          | int             | Sync/conflict çözümü           |                       |
| is_active        | boolean         | Soft delete                    | default:true          |

**Ek Tablolar:**  
- **users**: Kullanıcılar
- **shelters**: Barınaklar
- **disasters**: Afet olayları
- **help_request_logs**: Talep logları (durum değişimi, atama, notlar vs.)
- **files**: Ortak dosya meta tablosu (isteğe bağlı, blob/S3 vs.)

---

## 2. PostgreSQL/TypeORM Entity Örneği

```typescript name=src/modules/help/domain/help-request.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, Index } from 'typeorm';
import { User } from '../../users/domain/user.entity';
import { Shelter } from '../../shelters/domain/shelter.entity';
import { Disaster } from '../../disasters/domain/disaster.entity';

@Entity()
@Index(['status', 'priority'])
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, user => user.helpRequests)
  user: User;

  @ManyToOne(() => Shelter, { nullable: true })
  shelter: Shelter;

  @ManyToOne(() => Disaster, { nullable: true })
  disaster: Disaster;

  @Column('text')
  description: string;

  @Column({ type: 'varchar', default: 'open' })
  status: string;

  @Column({ type: 'varchar', default: 'med' })
  priority: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  @Index({ spatial: true })
  location: string;

  @Column('jsonb', { nullable: true })
  files: string[]; // Dosya URL dizisi

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ type: 'int', default: 1 })
  version: number;

  @Column({ default: true })
  is_active: boolean;
}
```

---

## 3. Flutter Data Model (`models/help_request.dart`)

```dart name=lib/models/help_request.dart
import 'package:hive/hive.dart';

part 'help_request.g.dart';

@HiveType(typeId: 1)
class HelpRequest extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String userId;
  @HiveField(2)
  final String? shelterId;
  @HiveField(3)
  final String? disasterId;
  @HiveField(4)
  final String description;
  @HiveField(5)
  final String status;
  @HiveField(6)
  final String priority;
  @HiveField(7)
  final double latitude;
  @HiveField(8)
  final double longitude;
  @HiveField(9)
  final List<String>? files;
  @HiveField(10)
  final DateTime createdAt;
  @HiveField(11)
  final DateTime updatedAt;
  @HiveField(12)
  final int version;
  @HiveField(13)
  final bool isActive;

  HelpRequest({
    required this.id,
    required this.userId,
    this.shelterId,
    this.disasterId,
    required this.description,
    required this.status,
    required this.priority,
    required this.latitude,
    required this.longitude,
    this.files,
    required this.createdAt,
    required this.updatedAt,
    required this.version,
    required this.isActive,
  });

  factory HelpRequest.fromJson(Map<String, dynamic> json) => HelpRequest(
        id: json['id'],
        userId: json['user_id'],
        shelterId: json['shelter_id'],
        disasterId: json['disaster_id'],
        description: json['description'],
        status: json['status'],
        priority: json['priority'],
        latitude: json['location']['coordinates'][1],
        longitude: json['location']['coordinates'][0],
        files: (json['files'] as List?)?.map((x) => x.toString()).toList(),
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
        version: json['version'],
        isActive: json['is_active'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'user_id': userId,
        'shelter_id': shelterId,
        'disaster_id': disasterId,
        'description': description,
        'status': status,
        'priority': priority,
        'location': {
          'coordinates': [longitude, latitude]
        },
        'files': files,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'version': version,
        'is_active': isActive,
      };
}
```

---

## 4. Uçtan Uca: Backend → API → Flutter

### a) Backend API (NestJS Controller)

```typescript name=src/modules/help/presentation/help-request.controller.ts
import { Controller, Get, Post, Body, Param, UseGuards, Query } from '@nestjs/common';
import { HelpRequestService } from '../application/help-request.service';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';

@Controller('help-requests')
@UseGuards(JwtAuthGuard)
export class HelpRequestController {
  constructor(private readonly service: HelpRequestService) {}

  @Get()
  async list(@Query('since') since?: string) {
    // Delta sync desteği (sadece güncellenenleri döner)
    return this.service.listHelpRequests(since ? new Date(since) : undefined);
  }

  @Post()
  async create(@Body() body: any) {
    return this.service.createHelpRequest(body);
  }

  @Get(':id')
  async get(@Param('id') id: string) {
    return this.service.getHelpRequestById(id);
  }
}
```

### b) Flutter Servis ve Provider

```dart name=lib/services/help_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/help_request.dart';

class HelpService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<HelpRequest>> fetchHelpRequests(String token, {DateTime? since}) async {
    final url = since == null
        ? "$baseUrl/help-requests"
        : "$baseUrl/help-requests?since=${since.toUtc().toIso8601String()}";
    final response = await http.get(
      Uri.parse(url),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => HelpRequest.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load help requests');
    }
  }

  Future<HelpRequest> createHelpRequest(String token, HelpRequest request) async {
    final response = await http.post(
      Uri.parse("$baseUrl/help-requests"),
      headers: {"Authorization": "Bearer $token", "Content-Type": "application/json"},
      body: jsonEncode(request.toJson()),
    );
    if (response.statusCode == 200 || response.statusCode == 201) {
      return HelpRequest.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to create help request');
    }
  }
}
```

---

## 5. Ek: Log ve Dosya Tablosu (Genişletme)

### a) help_request_logs

| id        | uuid (PK) | 
| help_request_id | uuid (FK) | 
| user_id   | uuid (FK) |
| action    | varchar   | (created, updated, assigned, closed, note, etc.)
| note      | text      | 
| created_at| timestamptz |

### b) files
| id        | uuid (PK) |
| url       | text      |
| owner_id  | uuid (FK) |
| type      | varchar   | (image, doc, video) |
| meta      | jsonb     |

---

## 6. Sync, Conflict ve Offline için Tavsiyeler

- Her kayıt `version` ve `updated_at` ile gelir.
- Flutter local DB (Hive/Isar) ile delta sync ve conflict çözüm mantığı kolayca uygulanır.
- Dosya upload için ayrı endpoint ve blob/S3 entegrasyonu önerilir.
- Tablolar ve modeller diğer modüller (alerts, shelters, donations, users) için aynı yapıda genişletilebilir.

---

**Başka bir modül için de uçtan uca şema ve veri modeli ister misiniz?**