# Tam Kapsamlı Afet Yönetim Sistemi – Her Modül için Derinlemesine Örnek (Domain / Application / Presentation / Guard)

Aşağıda, her modül için profesyonel ve sürdürülebilir bir mimariye uygun **domain/application/presentation/guard** örnek dosyaları ve açıklamaları sunulmaktadır.

---

## 1. Alerts Modülü

### domain/alert.entity.ts
```typescript
import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity()
export class Alert {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  type: string; // earthquake, flood, etc.

  @Column()
  title: string;

  @Column('text')
  description: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  risk_level: string;

  @Column()
  source: string;

  @Column({ default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

### application/alert.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alert } from '../domain/alert.entity';
import { CreateAlertDto } from './dto/create-alert.dto';

@Injectable()
export class AlertService {
  constructor(
    @InjectRepository(Alert)
    private readonly alertRepo: Repository<Alert>,
  ) {}

  async createAlert(dto: CreateAlertDto): Promise<Alert> {
    const alert = this.alertRepo.create(dto);
    return this.alertRepo.save(alert);
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return this.alertRepo.find({ where: { is_active: true } });
  }
}
```

### application/dto/create-alert.dto.ts
```typescript
import { IsString, IsNotEmpty, IsIn } from 'class-validator';

export class CreateAlertDto {
  @IsString()
  @IsIn(['earthquake', 'flood', 'fire', 'other'])
  type: string;

  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsString()
  @IsNotEmpty()
  location: string; // GeoJSON Point string

  @IsString()
  @IsIn(['low', 'medium', 'high'])
  risk_level: string;

  @IsString()
  source: string;
}
```

### presentation/alerts.controller.ts
```typescript
import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { AlertService } from '../application/alert.service';
import { CreateAlertDto } from '../application/dto/create-alert.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { Roles } from '../../shared/decorators/roles.decorator';
import { RolesGuard } from '../../shared/guards/roles.guard';

@Controller('alerts')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AlertsController {
  constructor(private readonly alertService: AlertService) {}

  @Roles('admin')
  @Post()
  async createAlert(@Body() dto: CreateAlertDto) {
    return this.alertService.createAlert(dto);
  }

  @Roles('admin', 'user')
  @Get()
  async getActiveAlerts() {
    return this.alertService.getActiveAlerts();
  }
}
```

### guard/jwt-auth.guard.ts
```typescript
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

### guard/roles.guard.ts
```typescript
import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.get<string[]>('roles', context.getHandler());
    if (!roles) return true;
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    return roles.includes(user.role);
  }
}
```

### decorators/roles.decorator.ts
```typescript
import { SetMetadata } from '@nestjs/common';

export const Roles = (...roles: string[]) => SetMetadata('roles', roles);
```

---

## 2. Users Modülü

### domain/user.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column()
  password_hash: string;

  @Column()
  display_name: string;

  @Column({ default: 'user' })
  role: string; // user, admin, child

  @Column({ default: false })
  is_anonymous: boolean;

  @Column({ default: false })
  mfa_enabled: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

### application/users.service.ts
```typescript
import { Injectable, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../domain/user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) {}

  async register(email: string, password: string, display_name: string) {
    if (await this.userRepo.findOne({ where: { email } })) {
      throw new ConflictException('Email already registered');
    }
    const user = this.userRepo.create({
      email,
      display_name,
      password_hash: await bcrypt.hash(password, 10),
    });
    return this.userRepo.save(user);
  }

  async findByEmail(email: string) {
    return this.userRepo.findOne({ where: { email } });
  }
}
```

### presentation/users.controller.ts
```typescript
import { Controller, Post, Body } from '@nestjs/common';
import { UsersService } from '../application/users.service';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  async register(@Body() body: { email: string; password: string; display_name: string }) {
    return this.usersService.register(body.email, body.password, body.display_name);
  }
}
```

### guard/jwt-auth.guard.ts
```typescript
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

---

## 3. Community Modülü

### domain/help-request.entity.ts
```typescript
import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity()
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: true })
  user_id: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // rescue, food, medical, other

  @Column()
  description: string;

  @Column({ default: 'open' })
  status: string; // open, matched, closed

  @Column({ default: false })
  reported: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

### application/community.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HelpRequest } from '../domain/help-request.entity';

@Injectable()
export class CommunityService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly helpRepo: Repository<HelpRequest>,
  ) {}

  async createHelpRequest(dto: { type: string; description: string; location: string }, userId: string) {
    const req = this.helpRepo.create({ ...dto, user_id: userId });
    return this.helpRepo.save(req);
  }

  async getOpenRequests() {
    return this.helpRepo.find({ where: { status: 'open' } });
  }
}
```

### presentation/community.controller.ts
```typescript
import { Controller, Post, Get, Body, Req, UseGuards } from '@nestjs/common';
import { CommunityService } from '../application/community.service';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';

@Controller('community')
export class CommunityController {
  constructor(private readonly communityService: CommunityService) {}

  @UseGuards(JwtAuthGuard)
  @Post('help-request')
  async createHelpRequest(@Body() dto: { type: string; description: string; location: string }, @Req() req) {
    return this.communityService.createHelpRequest(dto, req.user.id);
  }

  @Get('help-requests')
  async getOpenRequests() {
    return this.communityService.getOpenRequests();
  }
}
```

---

## 4. Moderation Modülü

### domain/moderation-log.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class ModerationLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  entity_type: string;

  @Column()
  entity_id: string;

  @Column()
  action: string; // approve, remove, block

  @Column({ nullable: true })
  user_id: string;

  @Column({ nullable: true })
  reason: string;

  @CreateDateColumn()
  created_at: Date;
}
```

### application/moderation.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ModerationLog } from '../domain/moderation-log.entity';
import { HelpRequest } from '../../community/domain/help-request.entity';

@Injectable()
export class ModerationService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly helpRepo: Repository<HelpRequest>,
    @InjectRepository(ModerationLog)
    private readonly modLogRepo: Repository<ModerationLog>,
  ) {}

  async moderateRequest(id: string, action: 'approve' | 'remove', moderatorId: string, reason?: string) {
    const req = await this.helpRepo.findOne({ where: { id } });
    if (!req) throw new Error('Request not found');
    if (action === 'remove') req.status = 'removed';
    else req.reported = false;
    await this.helpRepo.save(req);

    const log = this.modLogRepo.create({
      entity_type: 'HelpRequest',
      entity_id: id,
      action,
      user_id: moderatorId,
      reason,
    });
    await this.modLogRepo.save(log);
    return req;
  }
}
```

### presentation/moderation.controller.ts
```typescript
import { Controller, Patch, Param, Query, Req, UseGuards } from '@nestjs/common';
import { ModerationService } from '../application/moderation.service';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { Roles } from '../../shared/decorators/roles.decorator';
import { RolesGuard } from '../../shared/guards/roles.guard';

@Controller('moderation')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('admin', 'moderator')
export class ModerationController {
  constructor(private readonly moderationService: ModerationService) {}

  @Patch('request/:id')
  moderateRequest(
    @Param('id') id: string,
    @Query('action') action: 'approve' | 'remove',
    @Req() req,
    @Query('reason') reason?: string,
  ) {
    return this.moderationService.moderateRequest(id, action, req.user.id, reason);
  }
}
```

---

## 5. Guard Katmanı (Tüm modüller ortak)

### shared/guards/jwt-auth.guard.ts
```typescript
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

### shared/guards/roles.guard.ts
```typescript
import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.get<string[]>('roles', context.getHandler());
    if (!roles) return true;
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    return roles.includes(user.role);
  }
}
```

### shared/decorators/roles.decorator.ts
```typescript
import { SetMetadata } from '@nestjs/common';

export const Roles = (...roles: string[]) => SetMetadata('roles', roles);
```

---

Bu yapı her modül için **domain/application/presentation/guard** ayrımını, profesyonel best-practice ve sürdürülebilirliği sağlar.  
Benzer mantık diğer modüllere de kolayca genişletilebilir.  
Daha fazla örnek veya belirli modül için ek ayrıntı isterseniz belirtin!