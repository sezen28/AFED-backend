# Flutter Afet Yönetimi Uygulaması – Çoklu Dil, Offline Harita, Kriz/Enerji Modu, Bildirim Entegrasyonu

Aşağıda, afet yönetimi uygulamasına **çoklu dil (localization)**, **offline harita**, **kriz/enerji tasarruf modu** ve **bildirim** modüllerinin nasıl profesyonelce entegre edileceği anlatılmıştır.

---

## 1. Çoklu Dil (Localization)

### a) Paket Kurulumu
`pubspec.yaml`:
```yaml
dependencies:
  flutter_localizations:
    sdk: flutter
  intl: ^0.18.0
  easy_localization: ^3.0.3
```

### b) Assets/Translations Dosya Yapısı
```
assets/translations/
  en.json
  tr.json
  ar.json
```

Örnek `en.json`:
```json
{
  "alerts": "Alerts",
  "help": "Help Request",
  "shelter": "Shelter",
  "offline_mode": "Offline Mode Active",
  "energy_mode": "Energy Saving Mode"
}
```
`tr.json` da benzer şekilde Türkçe karşılıklarını içerir.

### c) main.dart ve Entegrasyon
```dart
import 'package:easy_localization/easy_localization.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  runApp(
    EasyLocalization(
      supportedLocales: [Locale('en'), Locale('tr'), Locale('ar')],
      path: 'assets/translations',
      fallbackLocale: Locale('en'),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  // ...
  Widget build(BuildContext context) {
    return MaterialApp(
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      // ...
    );
  }
}
```
Kullanım:
```dart
Text(tr('alerts'))
```

---

## 2. Offline Harita (OpenStreetMap/MBTiles)

### a) Paket Kurulumu
```yaml
dependencies:
  flutter_map: ^6.1.0
  latlong2: ^0.9.0
  mbtiles: ^2.1.0
```

### b) MBTiles ile Offline Tile Entegrasyonu
```dart
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:mbtiles/mbtiles.dart';

class OfflineMapScreen extends StatefulWidget {
  @override
  _OfflineMapScreenState createState() => _OfflineMapScreenState();
}

class _OfflineMapScreenState extends State<OfflineMapScreen> {
  late MBTilesImageProvider tileProvider;

  @override
  void initState() {
    super.initState();
    tileProvider = MBTilesImageProvider('assets/maps/city.mbtiles');
  }

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      options: MapOptions(center: LatLng(39.9, 32.85), zoom: 10),
      layers: [
        TileLayer(
          tileProvider: tileProvider,
          maxZoom: 18,
          minZoom: 6,
        ),
        // MarkerLayer ile barınak/uyarı marker'ları
      ],
    );
  }
}
```
> MBTiles dosyasını [MapTiler](https://www.maptiler.com/tools/mbtiles/) ile üretebilirsiniz.

---

## 3. Kriz/Enerji Tasarruf Modu

### a) Kriz/Enerji Modu Provider
```dart
import 'package:flutter/material.dart';

class CrisisProvider with ChangeNotifier {
  bool _crisisMode = false;
  bool _energySaving = false;

  bool get crisisMode => _crisisMode;
  bool get energySaving => _energySaving;

  void toggleCrisisMode() {
    _crisisMode = !_crisisMode;
    notifyListeners();
  }

  void toggleEnergySaving() {
    _energySaving = !_energySaving;
    notifyListeners();
  }
}
```

### b) Uygulamada Kullanımı
```dart
import 'package:provider/provider.dart';
import '../providers/crisis_provider.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final crisisProvider = Provider.of<CrisisProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('dashboard'.tr()),
        actions: [
          Switch(
            value: crisisProvider.crisisMode,
            onChanged: (_) => crisisProvider.toggleCrisisMode(),
            activeColor: Colors.red,
            inactiveThumbColor: Colors.grey,
          ),
          Switch(
            value: crisisProvider.energySaving,
            onChanged: (_) => crisisProvider.toggleEnergySaving(),
            activeColor: Colors.green,
            inactiveThumbColor: Colors.grey,
          ),
        ],
      ),
      body: crisisProvider.crisisMode
          ? Center(child: Text(tr('offline_mode')))
          : Container(/* normal dashboard */),
    );
  }
}
```
- Enerji modu aktifken, animasyonlar, GPS, arka plan sync gibi işlemler sınırlandırılır.

---

## 4. Bildirimler (Push ve Local Notifications)

### a) Paket Kurulumu
```yaml
dependencies:
  firebase_messaging: ^14.7.10
  flutter_local_notifications: ^16.3.1
```

### b) FCM Push Notification Entegrasyonu
```dart
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void setupNotifications() {
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    flutterLocalNotificationsPlugin.show(
      0,
      message.notification?.title ?? '',
      message.notification?.body ?? '',
      NotificationDetails(
        android: AndroidNotificationDetails('id', 'name', channelDescription: 'desc'),
      ),
    );
  });
}

// main.dart içinde:
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ... diğer init
  setupNotifications();
  runApp(MyApp());
}
```

- Push geldiğinde, örn. “alerts_update” ise cache güncellenebilir.
- Local notification ile internet yokken kritik uyarılar yine kullanıcıya gösterilebilir.

---

## 5. Notlar

- **Çoklu dil**: Her modül için tr(), .tr() ile çeviri sağlanır.
- **Offline harita**: MBTiles dışında tile caching ile de desteklenebilir.
- **Kriz/Enerji modu**: UI’da renk, tema veya erişim değişikliklerine olanak sağlar.
- **Bildirim**: Hem background sync tetikleme hem de kullanıcı bilgilendirmesi yapılır.

---