# Tam Kapsamlı Afet Yönetim Sistemi – Modül Bazlı Örnek Dosya İçerikleri ve Flutter

Aşağıda her ana backend modülü için birer örnek dosya içeriği ve, örnek olarak, Flutter tarafında bir modülün (ör: Alerts) temel dosya yapısı ve içerikleri sunulmuştur.

---

## 1. **auth** (backend)
### `application/auth.service.ts`
```typescript
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UsersService } from '../../users/application/users.service';
import { JwtService } from '@nestjs/jwt';
import { compare } from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
  ) {}
  async validateUser(email: string, password: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user || !(await compare(password, user.password_hash))) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return user;
  }
  async login(user: any) {
    const payload = { sub: user.id, role: user.role };
    return { access_token: this.jwtService.sign(payload) };
  }
}
```

---

## 2. **users** (backend)
### `domain/user.entity.ts`
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column()
  password_hash: string;

  @Column()
  display_name: string;

  @Column({ default: 'user' })
  role: string; // user, admin, child

  @Column({ default: false })
  is_anonymous: boolean;

  @Column({ default: false })
  mfa_enabled: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

---

## 3. **alerts** (backend)
### `application/alerts.service.ts`
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alert } from '../domain/alert.entity';
import { CreateAlertDto } from './dto/create-alert.dto';

@Injectable()
export class AlertsService {
  constructor(
    @InjectRepository(Alert)
    private readonly alertRepo: Repository<Alert>,
  ) {}

  async createAlert(dto: CreateAlertDto): Promise<Alert> {
    const alert = this.alertRepo.create(dto);
    return this.alertRepo.save(alert);
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return this.alertRepo.find({ where: { is_active: true } });
  }
}
```

---

## 4. **map** (backend)
### `domain/shelter.entity.ts`
```typescript
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Shelter {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // shelter, hospital, gathering_point

  @Column()
  capacity: number;

  @Column()
  available: number;
}
```

---

## 5. **community** (backend)
### `domain/help-request.entity.ts`
```typescript
import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity()
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: true })
  user_id: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // rescue, food, medical, other

  @Column()
  description: string;

  @Column({ default: 'open' })
  status: string; // open, matched, closed

  @Column({ default: false })
  reported: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

---

## 6. **ai** (backend)
### `application/ai.service.ts`
```typescript
import { Injectable, Logger } from '@nestjs/common';
import { AiMessageDto } from './dto/ai-message.dto';
import axios from 'axios';

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  async chatWithBot(dto: AiMessageDto) {
    try {
      const response = await axios.post('http://localhost:8000/api/bot/message', dto, { timeout: 5000 });
      return response.data;
    } catch (e) {
      this.logger.error('AI Bot service unreachable', e);
      return { reply: 'Şu an yardımcı olamıyorum. Lütfen tekrar deneyin.' };
    }
  }
}
```

---

## 7. **donations** (backend)
### `domain/donation.entity.ts`
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Donation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  campaign: string;

  @Column()
  donor_name: string;

  @Column()
  amount: number;

  @Column()
  currency: string;

  @CreateDateColumn()
  donated_at: Date;
}
```

---

## 8. **notifications** (backend)
### `application/notification.service.ts`
```typescript
import { Injectable } from '@nestjs/common';
import * as admin from 'firebase-admin';

@Injectable()
export class NotificationService {
  async sendPush(token: string, title: string, body: string, data?: Record<string, string>) {
    return admin.messaging().send({
      token,
      notification: { title, body },
      data: data || {},
    });
  }
}
```

---

## 9. **moderation** (backend)
### `application/moderation.service.ts`
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HelpRequest } from '../../community/domain/help-request.entity';

@Injectable()
export class ModerationService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly helpRepo: Repository<HelpRequest>,
  ) {}

  async getReportedRequests() {
    return this.helpRepo.find({ where: { reported: true } });
  }

  async moderateRequest(id: string, action: 'approve' | 'remove') {
    const req = await this.helpRepo.findOne({ where: { id } });
    if (!req) throw new Error('Request not found');
    if (action === 'remove') req.status = 'removed';
    else req.reported = false;
    await this.helpRepo.save(req);
    return req;
  }
}
```

---

## 10. **localization** (backend)
### `application/localization.service.ts`
```typescript
import { Injectable } from '@nestjs/common';

@Injectable()
export class LocalizationService {
  async getAvailableLanguages() {
    return ['tr', 'en', 'ar'];
  }

  async getTranslations(lang: string) {
    if (lang === 'tr') return { welcome: 'Hoşgeldiniz!' };
    if (lang === 'en') return { welcome: 'Welcome!' };
    if (lang === 'ar') return { welcome: 'مرحبا!' };
    return {};
  }
}
```

---

## 11. **crisis** (backend)
### `application/crisis.service.ts`
```typescript
import { Injectable } from '@nestjs/common';

@Injectable()
export class CrisisService {
  getCrisisModeInfo() {
    return {
      offlineMode: true,
      powerSave: true,
      emergencySignal: true,
    };
  }
}
```

---

# Flutter Örnek: Alerts Modülü

## Dosya Yapısı
```
lib/
  models/
    alert.dart
  services/
    api_service.dart
  screens/
    alerts_screen.dart
  widgets/
    alert_card.dart
```

---

### `models/alert.dart`
```dart
class Alert {
  final String id;
  final String type;
  final String title;
  final String description;
  final double latitude;
  final double longitude;
  final String riskLevel;
  final String createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  factory Alert.fromJson(Map<String, dynamic> json) => Alert(
        id: json['id'],
        type: json['type'],
        title: json['title'],
        description: json['description'],
        latitude: json['location']['coordinates'][1],
        longitude: json['location']['coordinates'][0],
        riskLevel: json['risk_level'],
        createdAt: json['created_at'],
      );
}
```

---

### `services/api_service.dart`
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/alert.dart';

class ApiService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<Alert>> fetchAlerts() async {
    final response = await http.get(Uri.parse("$baseUrl/alerts"));
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => Alert.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load alerts');
    }
  }
}
```

---

### `screens/alerts_screen.dart`
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';
import '../services/api_service.dart';
import '../widgets/alert_card.dart';

class AlertsScreen extends StatelessWidget {
  final ApiService apiService = ApiService();

  AlertsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Aktif Afet Uyarıları")),
      body: FutureBuilder<List<Alert>>(
        future: apiService.fetchAlerts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return Center(child: Text("Yüklenemedi: ${snapshot.error}"));
          final alerts = snapshot.data ?? [];
          return ListView.builder(
            itemCount: alerts.length,
            itemBuilder: (context, index) => AlertCard(alert: alerts[index]),
          );
        },
      ),
    );
  }
}
```

---

### `widgets/alert_card.dart`
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';

class AlertCard extends StatelessWidget {
  final Alert alert;
  const AlertCard({Key? key, required this.alert}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(alert.title),
        subtitle: Text(alert.description),
        trailing: Text(alert.riskLevel.toUpperCase()),
      ),
    );
  }
}
```

---

Her modül için bu şekilde backend ve Flutter istemci tarafında dosya ve içerik örnekleri çoğaltılabilir.  
Belirli bir modül veya daha derinlemesine backend ya da Flutter entegrasyonu örneği isterseniz belirtin!