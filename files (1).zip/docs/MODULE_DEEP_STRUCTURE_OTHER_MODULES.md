# Tam Kapsamlı Afet Yönetim Sistemi – Diğer Modüller için Domain / Application / Presentation / Guard Örnekleri

Aşağıda, **alerts** modülündeki profesyonel mimariyi temel alarak, diğer ana modüller için de aynı domain/application/presentation/guard katmanlarının örnek dosya içerikleri sunulmuştur.

---

## 1. **map** Modülü (Harita ve Barınaklar)

### domain/shelter.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Shelter {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // shelter, hospital, gathering_point

  @Column()
  capacity: number;

  @Column()
  available: number;
}
```

### application/map.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Shelter } from '../domain/shelter.entity';
import { CreateShelterDto } from './dto/create-shelter.dto';

@Injectable()
export class MapService {
  constructor(
    @InjectRepository(Shelter)
    private readonly shelterRepo: Repository<Shelter>,
  ) {}

  async createShelter(dto: CreateShelterDto): Promise<Shelter> {
    const shelter = this.shelterRepo.create(dto);
    return this.shelterRepo.save(shelter);
  }

  async getAllShelters(): Promise<Shelter[]> {
    return this.shelterRepo.find();
  }
}
```

### application/dto/create-shelter.dto.ts
```typescript
import { IsString, IsNotEmpty, IsNumber } from 'class-validator';

export class CreateShelterDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  location: string; // GeoJSON Point string

  @IsString()
  @IsNotEmpty()
  type: string;

  @IsNumber()
  capacity: number;

  @IsNumber()
  available: number;
}
```

### presentation/map.controller.ts
```typescript
import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { MapService } from '../application/map.service';
import { CreateShelterDto } from '../application/dto/create-shelter.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';
import { Roles } from '../../shared/decorators/roles.decorator';
import { RolesGuard } from '../../shared/guards/roles.guard';

@Controller('map')
@UseGuards(JwtAuthGuard, RolesGuard)
export class MapController {
  constructor(private readonly mapService: MapService) {}

  @Roles('admin')
  @Post('shelter')
  async createShelter(@Body() dto: CreateShelterDto) {
    return this.mapService.createShelter(dto);
  }

  @Roles('admin', 'user')
  @Get('shelters')
  async getAllShelters() {
    return this.mapService.getAllShelters();
  }
}
```

---

## 2. **ai** Modülü (AI Destekli Yardım)

### domain/ai-interaction.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class AiInteraction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  user_id: string;

  @Column()
  message: string;

  @Column('text')
  response: string;

  @CreateDateColumn()
  created_at: Date;
}
```

### application/ai.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AiInteraction } from '../domain/ai-interaction.entity';
import { AiMessageDto } from './dto/ai-message.dto';
import axios from 'axios';

@Injectable()
export class AiService {
  constructor(
    @InjectRepository(AiInteraction)
    private readonly aiRepo: Repository<AiInteraction>,
  ) {}

  async chatWithBot(dto: AiMessageDto) {
    // AI mikroservisine istek atılır
    const aiRes = await axios.post('http://localhost:8000/api/bot/message', dto, { timeout: 5000 });
    const saved = this.aiRepo.create({
      user_id: dto.user_id,
      message: dto.message,
      response: aiRes.data.reply,
    });
    await this.aiRepo.save(saved);
    return aiRes.data;
  }
}
```

### application/dto/ai-message.dto.ts
```typescript
import { IsString, IsNotEmpty } from 'class-validator';

export class AiMessageDto {
  @IsString()
  @IsNotEmpty()
  user_id: string;

  @IsString()
  @IsNotEmpty()
  message: string;

  @IsString()
  locale: string;
}
```

### presentation/ai.controller.ts
```typescript
import { Controller, Post, Body, UseGuards, Req } from '@nestjs/common';
import { AiService } from '../application/ai.service';
import { AiMessageDto } from '../application/dto/ai-message.dto';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';

@Controller('ai')
@UseGuards(JwtAuthGuard)
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('bot/message')
  async chat(@Body() dto: AiMessageDto, @Req() req) {
    // user_id güvenli şekilde req.user.id üzerinden alınabilir
    return this.aiService.chatWithBot({ ...dto, user_id: req.user.id });
  }
}
```

---

## 3. **donations** Modülü (Bağış)

### domain/donation.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Donation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  campaign: string;

  @Column()
  donor_name: string;

  @Column()
  amount: number;

  @Column()
  currency: string;

  @CreateDateColumn()
  donated_at: Date;
}
```

### application/donations.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Donation } from '../domain/donation.entity';

@Injectable()
export class DonationsService {
  constructor(
    @InjectRepository(Donation)
    private readonly donationRepo: Repository<Donation>,
  ) {}

  async donate(data: { campaign: string; donor_name: string; amount: number; currency: string }) {
    const donation = this.donationRepo.create(data);
    return this.donationRepo.save(donation);
  }

  async getCampaignDonations(campaign: string) {
    return this.donationRepo.find({ where: { campaign } });
  }
}
```

### presentation/donations.controller.ts
```typescript
import { Controller, Post, Get, Body, Query } from '@nestjs/common';
import { DonationsService } from '../application/donations.service';

@Controller('donations')
export class DonationsController {
  constructor(private readonly donationsService: DonationsService) {}

  @Post()
  async donate(@Body() data: { campaign: string; donor_name: string; amount: number; currency: string }) {
    return this.donationsService.donate(data);
  }

  @Get()
  async getCampaignDonations(@Query('campaign') campaign: string) {
    return this.donationsService.getCampaignDonations(campaign);
  }
}
```

---

## 4. **notifications** Modülü (Bildirim)

### domain/notification.entity.ts
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Notification {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  user_id: string;

  @Column()
  type: string; // push, sms, email

  @Column()
  message: string;

  @Column({ default: 'pending' })
  status: string; // pending, sent, failed

  @CreateDateColumn()
  sent_at: Date;
}
```

### application/notification.service.ts
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Notification } from '../domain/notification.entity';

@Injectable()
export class NotificationService {
  constructor(
    @InjectRepository(Notification)
    private readonly notificationRepo: Repository<Notification>,
  ) {}

  async sendNotification(dto: { user_id: string; type: string; message: string }) {
    // Push/SMS/email gönderimini gerçek servislerle entegre edin
    const notification = this.notificationRepo.create({ ...dto, status: 'sent' });
    return this.notificationRepo.save(notification);
  }
}
```

### presentation/notifications.controller.ts
```typescript
import { Controller, Post, Body, UseGuards, Req } from '@nestjs/common';
import { NotificationService } from '../application/notification.service';
import { JwtAuthGuard } from '../../shared/guards/jwt-auth.guard';

@Controller('notifications')
@UseGuards(JwtAuthGuard)
export class NotificationsController {
  constructor(private readonly notificationService: NotificationService) {}

  @Post()
  async sendNotification(@Body() dto: { type: string; message: string }, @Req() req) {
    // user_id güvenli şekilde req.user.id üzerinden alınır
    return this.notificationService.sendNotification({ ...dto, user_id: req.user.id });
  }
}
```

---

## 5. Guard Katmanı (Tüm modüller ortak olarak kullanır)

Yukarıda örnekleri verilen `jwt-auth.guard.ts`, `roles.guard.ts`, `roles.decorator.ts` dosyaları her modülde kullanılabilir.

---

**Not:**  
- Buradaki örnekler, her modülün domain/model, servis, controller ve guard yapısını temel alınarak hazırlanmıştır.
- Tüm modüller bu mimaride kolayca genişletilebilir ve entegre edilebilir.
- Daha ileri seviye (ör. event-driven, microservice, test, CQRS, cache) veya diğer modüller için de örnek kodlar eklenebilir.

---