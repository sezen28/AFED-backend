# Tam Flutter-Backend Uçtan Uca Entegrasyon – Afet Yönetim Sistemi

Aşağıda, **Flutter mobil istemcisinin** ve **NestJS/TypeORM tabanlı profesyonel backend API'nin** uçtan uca (end-to-end) entegrasyonuna dair örnek yapı ve kod örnekleri bulacaksınız.  
Bu örnek, JWT ile kimlik doğrulama, afet uyarılarını çekme ve görüntüleme iş akışını kapsar. Diğer modüller için de benzer mantıkla genişletilebilir.

---

## 1. Backend (NestJS) – Alerts Örneği

### 1.1 Alert Entity (`src/modules/alerts/domain/alert.entity.ts`)
```typescript
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Alert {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  type: string;

  @Column()
  title: string;

  @Column('text')
  description: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  risk_level: string;

  @Column({ default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;
}
```

---

### 1.2 Alert Service (`src/modules/alerts/application/alert.service.ts`)
```typescript
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alert } from '../domain/alert.entity';

@Injectable()
export class AlertService {
  constructor(
    @InjectRepository(Alert)
    private readonly alertRepo: Repository<Alert>,
  ) {}

  async getActiveAlerts(): Promise<Alert[]> {
    return this.alertRepo.find({ where: { is_active: true } });
  }
}
```

---

### 1.3 Alert Controller (`src/modules/alerts/presentation/alerts.controller.ts`)
```typescript
import { Controller, Get, UseGuards } from '@nestjs/common';
import { AlertService } from '../application/alert.service';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';

@Controller('alerts')
@UseGuards(JwtAuthGuard)
export class AlertsController {
  constructor(private readonly alertService: AlertService) {}

  @Get()
  async getActiveAlerts() {
    return this.alertService.getActiveAlerts();
  }
}
```

---

### 1.4 Auth Login Controller (`src/modules/auth/presentation/auth.controller.ts`)
```typescript
import { Controller, Post, Body } from '@nestjs/common';
import { AuthService } from '../application/auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() { email, password }: { email: string; password: string }) {
    const user = await this.authService.validateUser(email, password);
    return this.authService.login(user);
  }
}
```

---

### 1.5 JWT Guard (`src/shared/guards/jwt-auth.guard.ts`)
```typescript
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

---

## 2. Flutter – Alerts Modülüne Uçtan Uca Erişim

### 2.1 Model (`lib/models/alert.dart`)
```dart
class Alert {
  final String id;
  final String type;
  final String title;
  final String description;
  final double latitude;
  final double longitude;
  final String riskLevel;
  final String createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  factory Alert.fromJson(Map<String, dynamic> json) => Alert(
    id: json['id'],
    type: json['type'],
    title: json['title'],
    description: json['description'],
    latitude: json['location']['coordinates'][1],
    longitude: json['location']['coordinates'][0],
    riskLevel: json['risk_level'],
    createdAt: json['created_at'],
  );
}
```

---

### 2.2 Auth Servisi (`lib/services/auth_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  final String baseUrl = "https://api.afetapp.com";

  Future<String> login(String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/auth/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "password": password}),
    );
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      return data['access_token'];
    } else {
      throw Exception('Login failed');
    }
  }
}
```

---

### 2.3 Alert Servisi (`lib/services/api_service.dart`)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/alert.dart';

class ApiService {
  final String baseUrl = "https://api.afetapp.com";

  Future<List<Alert>> fetchAlerts(String token) async {
    final response = await http.get(
      Uri.parse("$baseUrl/alerts"),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => Alert.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load alerts');
    }
  }
}
```

---

### 2.4 Provider (`lib/providers/alerts_provider.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';
import '../services/api_service.dart';

class AlertsProvider with ChangeNotifier {
  final ApiService apiService;
  final String token;

  AlertsProvider(this.apiService, this.token);

  List<Alert> _alerts = [];
  bool _loading = false;
  String? _error;

  List<Alert> get alerts => _alerts;
  bool get loading => _loading;
  String? get error => _error;

  Future<void> loadAlerts() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      _alerts = await apiService.fetchAlerts(token);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }
}
```

---

### 2.5 Alert Ekranı (`lib/screens/alerts_screen.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/alerts_provider.dart';
import '../widgets/alert_card.dart';

class AlertsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AlertsProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text("Afet Uyarıları")),
      body: provider.loading
          ? Center(child: CircularProgressIndicator())
          : provider.error != null
            ? Center(child: Text("Hata: ${provider.error}"))
            : ListView.builder(
                itemCount: provider.alerts.length,
                itemBuilder: (context, i) =>
                    AlertCard(alert: provider.alerts[i]),
              ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => provider.loadAlerts(),
        child: Icon(Icons.refresh),
      ),
    );
  }
}
```

---

### 2.6 Alert Widget (`lib/widgets/alert_card.dart`)
```dart
import 'package:flutter/material.dart';
import '../models/alert.dart';

class AlertCard extends StatelessWidget {
  final Alert alert;
  const AlertCard({Key? key, required this.alert}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: alert.riskLevel == "high"
          ? Colors.red[100]
          : alert.riskLevel == "medium"
              ? Colors.orange[100]
              : Colors.green[100],
      child: ListTile(
        title: Text(alert.title),
        subtitle: Text(alert.description),
        trailing: Text(alert.riskLevel.toUpperCase()),
      ),
    );
  }
}
```

---

### 2.7 Ana Dosya (`lib/main.dart`)
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'providers/alerts_provider.dart';
import 'screens/alerts_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String demoToken = "YOUR_JWT_TOKEN"; // Oturum açınca alınacak

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AlertsProvider(ApiService(), demoToken)..loadAlerts(),
        ),
      ],
      child: MaterialApp(
        title: 'Afet App',
        home: AlertsScreen(),
      ),
    );
  }
}
```

---

## 3. Uçtan Uca Akış

1. **Kullanıcı Flutter uygulamasında giriş ekranında email/şifre ile login olur.**
   - `AuthService.login(...)` ile backend’den JWT alınır.
2. **JWT token ile AlertsProvider oluşturulur ve kullanıcının afet uyarıları yüklenir.**
3. **Alert ekranında afet uyarıları listelenir, yenileme ve detay için API’ye güvenli istek yapılır.**
4. **Tüm istekler JWT ile yetkili yapılır, backend tarafında JwtAuthGuard ile kontrol edilir.**
5. **Backend tarafında TypeORM ile veri kalıcı olarak yönetilir.**

---

## Notlar

- Diğer modüller için de (yardım, harita, bağış, AI, bildirim vb.) aynı mantıkla ekran, model, servis ve provider eklenir.
- Error handling, token refresh, offline cache, localization, push notification gibi gelişmiş özellikler kolayca entegre edilebilir.
- Gerçek cihazda backend adresi için uygun baseUrl kullanılmalı.
- Backend tarafında CORS ve HTTPS yapılandırması unutulmamalı.
- Testler için Flutter’ın test altyapısı ve backend için Postman veya Swagger kullanılabilir.

---

**Daha ileri düzey entegrasyon (ör. offline-first, gerçek zamanlı bildirim, AI chat, kriz modu) veya başka modül örneği ister misiniz?**