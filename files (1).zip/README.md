# Tam Kapsamlı Afet Yönetim Sistemi

Bu doküman, kurumsal düzeyde, güvenli, ölçeklenebilir ve sürdürülebilir bir **Afet Yönetim Sistemi** için yazılım mimarisi, ana modüller, teknik detaylar ve örnek dosya yapısı sunar. Sistem hem web (backend) hem de mobil istemcileri (Flutter) kapsayacak biçimde tasarlanmıştır.

---

## 1. Hedefler ve Özellikler

- **Çoklu Afet Türü Desteği:** Deprem, sel, yangın, vs.
- **Gerçek Zamanlı Uyarı:** Resmi kaynaklar, sosyal medya, topluluk raporları.
- **Canlı Harita:** Barınaklar, hastaneler, risk bölgeleri, toplanma noktaları, AI destekli güvenli rota.
- **Topluluk Destek Platformu:** Yardım/bağış talepleri, kayıp kişi bildirimi, gönüllü eşleştirme, anlık mesajlaşma.
- **AI Destekli Yardım & Bilgi Botu:** Kriz anında rehberlik, psikolojik destek.
- **Kullanıcı Yönetimi:** Rol tabanlı erişim, çocuk profili, gizlilik/anonimlik, çoklu dil desteği.
- **Kriz Modu:** Offline çalışma, acil durum sinyali, enerji tasarrufu.
- **Kapsamlı Bilgi Kütüphanesi:** Eğitim, rehberler, testler, simülasyonlar.
- **Yönetici Modülü:** Moderasyon, içerik yönetimi, analiz ve loglama.
- **Yüksek Güvenlik & Yasal Uyum:** JWT/MFA, rate-limiting, şifreleme, KVKK/GDPR.

---

## 2. Ana Modüller

- **auth**: Kimlik doğrulama, JWT, MFA, rol yönetimi
- **users**: Profil, çocuk/anonim mod, KVKK ayarları
- **alerts**: Afet uyarı sistemi, sosyal medya analizi
- **map**: Harita, barınaklar, risk bölgeleri, rota
- **community**: Yardım/bağış, kayıp kişiler, mesajlaşma
- **ai**: AI destekli yardım botu, öneriler
- **knowledge**: Rehber, test, eğitim içeriği
- **donations**: Bağış kampanyaları ve yönetimi
- **notifications**: Push/SMS/email bildirim
- **moderation**: İçerik denetimi, raporlama
- **admin**: Kullanıcı ve sistem yönetimi, analiz
- **monitoring**: Sağlık, loglama, istatistik
- **localization**: Çoklu dil, çeviri yönetimi
- **crisis**: Kriz/afette offline çalışma ve acil mod

---

## 3. Modern ve Güvenli Mimarinin Temel Prensipleri

- **Katmanlı ve Modüler Mimari**
- **Microservices** (Docker, Kubernetes ile dağıtım)
- **API Gateway** (rate limit, auth, logging)
- **Database:** PostgreSQL (transactional), MongoDB (geo), Redis (cache)
- **CI/CD:** Otomatik test ve deployment (GitHub Actions, test coverage)
- **Infrastructure as Code:** Terraform/Ansible
- **Monitoring:** Prometheus, Grafana, Sentry, merkezi log
- **Yasal Uyum:** KVKK/GDPR, açık rıza, veri silme hakkı
- **Audit Trail & Logging:** Tüm kritik işlemler için merkezi log

---

## 4. Örnek Backend Dosya Yapısı (NestJS, TypeORM, Swagger)

```
src/
  modules/
    alerts/
      domain/alert.entity.ts
      application/alert.service.ts
      application/dto/create-alert.dto.ts
      presentation/alerts.controller.ts
    auth/
      application/auth.service.ts
      presentation/auth.controller.ts
    users/
      domain/user.entity.ts
      application/users.service.ts
      presentation/users.controller.ts
    community/
    ai/
    knowledge/
    donations/
    map/
    moderation/
    notifications/
    admin/
    crisis/
    monitoring/
    localization/
  shared/
    logger/
    guards/
    decorators/
    filters/
    utils/
  config/
    configuration.ts
  main.ts
  app.module.ts
```

---

## 5. Modül Kısa Açıklamaları

- **alerts:** Resmi ve topluluk kaynaklı afet uyarılarını toplar, filtreler ve kullanıcılara anında iletir. Sosyal medya analiz servisiyle entegre çalışır.
- **map:** Afet bölgeleri, barınaklar, toplanma noktaları ve güvenli rotaları sağlar. GeoJSON, AI tabanlı rota önerileri sunar.
- **community:** Yardım talepleri, gönüllü eşleştirmesi, kayıp kişi bildirimi, bağış ve topluluk mesajlaşmasını içerir.
- **ai:** AI tabanlı yardım ve bilgilendirme botu, davranışsal analiz, kişisel öneri ve psikolojik destek.
- **knowledge:** Afet eğitimleri, rehber içerikler, interaktif simülasyonlar.
- **donations:** Bağış kampanyaları, takibi ve finansal kayıtlar.
- **moderation:** İçerik denetimi, kullanıcı raporları, otomatik/manuel moderasyon.
- **admin:** Tüm sistem kaynaklarının ve kullanıcıların merkezi yönetimi, istatistik ve raporlama.
- **monitoring:** Uygulama sağlık kontrolleri, loglama, uyarı ve hata yönetimi.
- **localization:** Çoklu dil için içerik ve mesaj yönetimi.
- **crisis:** Offline/kriz modu, acil durum işlemleri, enerji ve veri optimizasyonu.

---

## 6. Örnekler: Temel Kod Blokları

### 6.1 Authentication (JWT, MFA, RBAC)

```typescript name=src/modules/auth/application/auth.service.ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UsersService } from '../../users/application/users.service';
import { JwtService } from '@nestjs/jwt';
import { compare } from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
  ) {}
  async validateUser(email: string, password: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user || !(await compare(password, user.password_hash))) {
      throw new UnauthorizedException('Invalid credentials');
    }
    return user;
  }
  async login(user: any) {
    const payload = { sub: user.id, role: user.role };
    return { access_token: this.jwtService.sign(payload) };
  }
}
```

### 6.2 Alerts (Afet Uyarısı CRUD)

```typescript name=src/modules/alerts/presentation/alerts.controller.ts
import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { AlertService } from '../application/alert.service';
import { CreateAlertDto } from '../application/dto/create-alert.dto';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';
import { Roles } from '../../../shared/decorators/roles.decorator';
import { RolesGuard } from '../../../shared/guards/roles.guard';

@Controller('alerts')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AlertsController {
  constructor(private readonly alertService: AlertService) {}
  @Roles('admin')
  @Post()
  async createAlert(@Body() dto: CreateAlertDto) {
    return this.alertService.createAlert(dto);
  }
  @Roles('admin', 'user')
  @Get()
  async getActiveAlerts() {
    return this.alertService.getActiveAlerts();
  }
}
```

### 6.3 Notifications (Push/SMS)

```typescript name=src/modules/notifications/application/notification.service.ts
import { Injectable } from '@nestjs/common';
import * as admin from 'firebase-admin';

@Injectable()
export class NotificationService {
  async sendPush(token: string, title: string, body: string, data?: Record<string, string>) {
    return admin.messaging().send({
      token,
      notification: { title, body },
      data: data || {},
    });
  }
}
```

---

## 7. Mobil: Flutter Dosya Yapısı

```
lib/
  screens/
    alerts_screen.dart
    map_screen.dart
    help_request_screen.dart
    ai_bot_screen.dart
    profile_screen.dart
    crisis_mode_screen.dart
  services/
    api_service.dart
    notification_service.dart
    offline_cache.dart
    localization_service.dart
  models/
    alert.dart
    user.dart
    help_request.dart
    shelter.dart
  widgets/
  main.dart
```

---

## 8. Güvenlik ve Kurumsal Prensipler

- **RBAC, JWT, MFA**, her API’da rol kontrolü
- **HTTPs zorunlu**, mTLS iç servisler arası
- **Rate limiting, brute force korunması**
- **Veri şifreleme** (db, at rest, in transit)
- **Audit log, merkezi loglama**
- **Automated test, CI/CD pipeline**
- **Yasal uyumluluk:** KVKK/GDPR, veri anonimleştirme, silme hakkı

---

## 9. Geliştirici ve DevOps

- **Swagger/OpenAPI** dökümantasyon
- **Config yönetimi:** .env + config dosyası
- **Prod/dev test ayrımı**
- **Otomatik testler ve coverage**
- **Kubernetes/Helm ile ölçeklenebilir dağıtım**

---

## 10. Genişletilebilirlik

Her modül bağımsız geliştirilip deploy edilebilir. Yeni afet türleri, üçüncü parti entegrasyonlar, yeni bildirim kanalları vb. eklenebilir.

---

**Daha fazla detay (ör. tam modül kodları, Flutter sayfa örnekleri, test stratejileri, CI/CD pipeline örnekleri) için belirtebilirsiniz!**