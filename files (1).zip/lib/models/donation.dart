import 'package:hive/hive.dart';

part 'donation.g.dart';

@HiveType(typeId: 5)
class Donation extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String userId;
  @HiveField(2)
  final String type;
  @HiveField(3)
  final double? amount;
  @HiveField(4)
  final String? description;
  @HiveField(5)
  final DateTime createdAt;

  Donation({
    required this.id,
    required this.userId,
    required this.type,
    this.amount,
    this.description,
    required this.createdAt,
  });

  factory Donation.fromJson(Map<String, dynamic> json) => Donation(
    id: json['id'],
    userId: json['user']['id'],
    type: json['type'],
    amount: json['amount'] == null ? null : double.tryParse(json['amount'].toString()),
    description: json['description'],
    createdAt: DateTime.parse(json['created_at']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'user_id': userId,
    'type': type,
    'amount': amount,
    'description': description,
    'created_at': createdAt.toIso8601String(),
  };
}