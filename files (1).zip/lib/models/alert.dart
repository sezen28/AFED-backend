import 'package:hive/hive.dart';

part 'alert.g.dart';

@HiveType(typeId: 6)
class Alert extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String type;
  @HiveField(2)
  final String title;
  @HiveField(3)
  final String description;
  @HiveField(4)
  final double latitude;
  @HiveField(5)
  final double longitude;
  @HiveField(6)
  final String riskLevel;
  @HiveField(7)
  final DateTime createdAt;

  Alert({
    required this.id,
    required this.type,
    required this.title,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.riskLevel,
    required this.createdAt,
  });

  factory Alert.fromJson(Map<String, dynamic> json) => Alert(
    id: json['id'],
    type: json['type'],
    title: json['title'],
    description: json['description'],
    latitude: json['location']['coordinates'][1],
    longitude: json['location']['coordinates'][0],
    riskLevel: json['risk_level'],
    createdAt: DateTime.parse(json['created_at']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type,
    'title': title,
    'description': description,
    'location': {'coordinates': [longitude, latitude]},
    'risk_level': riskLevel,
    'created_at': createdAt.toIso8601String(),
  };
}