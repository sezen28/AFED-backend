import 'package:hive/hive.dart';

part 'ai_message.g.dart';

@HiveType(typeId: 7)
class AIMessage extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String message;
  @HiveField(2)
  final bool isUser;
  @HiveField(3)
  final DateTime createdAt;

  AIMessage({
    required this.id,
    required this.message,
    required this.isUser,
    required this.createdAt,
  });

  factory AIMessage.fromJson(Map<String, dynamic> json) => AIMessage(
    id: json['id'],
    message: json['message'],
    isUser: json['is_user'],
    createdAt: DateTime.parse(json['created_at']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'message': message,
    'is_user': isUser,
    'created_at': createdAt.toIso8601String(),
  };
}