import 'package:hive/hive.dart';

part 'notification.g.dart';

@HiveType(typeId: 4)
class NotificationMessage extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String title;
  @HiveField(2)
  final String content;
  @HiveField(3)
  final bool isRead;
  @HiveField(4)
  final DateTime createdAt;

  NotificationMessage({
    required this.id,
    required this.title,
    required this.content,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationMessage.fromJson(Map<String, dynamic> json) => NotificationMessage(
    id: json['id'],
    title: json['title'],
    content: json['content'],
    isRead: json['is_read'],
    createdAt: DateTime.parse(json['created_at']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'content': content,
    'is_read': isRead,
    'created_at': createdAt.toIso8601String(),
  };
}