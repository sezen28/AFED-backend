import 'package:hive/hive.dart';

part 'shelter.g.dart';

@HiveType(typeId: 3)
class Shelter extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String name;
  @HiveField(2)
  final String city;
  @HiveField(3)
  final int capacity;
  @HiveField(4)
  final double latitude;
  @HiveField(5)
  final double longitude;
  @HiveField(6)
  final DateTime createdAt;

  Shelter({
    required this.id,
    required this.name,
    required this.city,
    required this.capacity,
    required this.latitude,
    required this.longitude,
    required this.createdAt,
  });

  factory Shelter.fromJson(Map<String, dynamic> json) => Shelter(
    id: json['id'],
    name: json['name'],
    city: json['city'],
    capacity: json['capacity'],
    latitude: json['location']['coordinates'][1],
    longitude: json['location']['coordinates'][0],
    createdAt: DateTime.parse(json['created_at']),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'city': city,
    'capacity': capacity,
    'location': {'coordinates': [longitude, latitude]},
    'created_at': createdAt.toIso8601String(),
  };
}