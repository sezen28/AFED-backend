import 'package:hive/hive.dart';

part 'help_request.g.dart';

@HiveType(typeId: 1)
class HelpRequest extends HiveObject {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String userId;
  @HiveField(2)
  final String? shelterId;
  @HiveField(3)
  final String? disasterId;
  @HiveField(4)
  final String description;
  @HiveField(5)
  final String status;
  @HiveField(6)
  final String priority;
  @HiveField(7)
  final double latitude;
  @HiveField(8)
  final double longitude;
  @HiveField(9)
  final List<String>? files;
  @HiveField(10)
  final DateTime createdAt;
  @HiveField(11)
  final DateTime updatedAt;
  @HiveField(12)
  final int version;
  @HiveField(13)
  final bool isActive;

  HelpRequest({
    required this.id,
    required this.userId,
    this.shelterId,
    this.disasterId,
    required this.description,
    required this.status,
    required this.priority,
    required this.latitude,
    required this.longitude,
    this.files,
    required this.createdAt,
    required this.updatedAt,
    required this.version,
    required this.isActive,
  });

  factory HelpRequest.fromJson(Map<String, dynamic> json) => HelpRequest(
        id: json['id'],
        userId: json['user']['id'] ?? json['user_id'],
        shelterId: json['shelter']?['id'] ?? json['shelter_id'],
        disasterId: json['disaster']?['id'] ?? json['disaster_id'],
        description: json['description'],
        status: json['status'],
        priority: json['priority'],
        latitude: json['location']['coordinates'][1],
        longitude: json['location']['coordinates'][0],
        files: (json['files'] as List?)?.map((x) => x.toString()).toList(),
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
        version: json['version'],
        isActive: json['is_active'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'user_id': userId,
        'shelter_id': shelterId,
        'disaster_id': disasterId,
        'description': description,
        'status': status,
        'priority': priority,
        'location': {
          'coordinates': [longitude, latitude]
        },
        'files': files,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
        'version': version,
        'is_active': isActive,
      };
}