import 'package:hive/hive.dart';
import '../models/help_request.dart';

class HelpQueue {
  static const String boxKey = 'help_queue';

  static Future<void> addToQueue(HelpRequest req) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.add(req);
  }

  static Future<List<HelpRequest>> getQueue() async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    return box.values.toList();
  }

  static Future<void> removeFromQueue(int index) async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.deleteAt(index);
  }

  static Future<void> clearQueue() async {
    final box = await Hive.openBox<HelpRequest>(boxKey);
    await box.clear();
  }
}