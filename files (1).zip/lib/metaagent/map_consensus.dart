class MapProposal {
  final String id;
  final String agentId;
  final Map<String, dynamic> mapData;
  int votes = 0;
  MapProposal(this.id, this.agentId, this.mapData);

  void vote() => votes += 1;
}

class MapConsensusEngine {
  final List<MapProposal> proposals = [];

  void submitProposal(MapProposal p) => proposals.add(p);

  MapProposal? selectBest() {
    if (proposals.isEmpty) return null;
    proposals.sort((a, b) => b.votes.compareTo(a.votes));
    return proposals.first;
  }
}