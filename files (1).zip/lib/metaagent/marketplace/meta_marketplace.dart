import 'dart:math';

class MetaAgentDeal {
  final String dealId;
  final String taskId;
  final List<String> participantAgentIds;
  final double agreedReward;
  final String cryptographicProof; // ZKP veya MPC kanıtı
  final String contractHash;
  bool isCompleted;

  MetaAgentDeal({
    required this.dealId,
    required this.taskId,
    required this.participantAgentIds,
    required this.agreedReward,
    required this.cryptographicProof,
    required this.contractHash,
    this.isCompleted = false,
  });
}

class MetaMarketplace {
  final Map<String, List<double>> bids = {}; // taskId -> [agentId, teklif]
  final List<MetaAgentDeal> deals = [];

  void submitBid(String taskId, String agentId, double price) {
    bids.putIfAbsent(taskId, () => []);
    bids[taskId]!.add(price + Random().nextDouble() * 0.01); // randomness for privacy
  }

  MetaAgentDeal? finalizeDeal(String taskId, List<String> agents, String zkp, String contractHash) {
    if (!bids.containsKey(taskId) || agents.isEmpty) return null;
    double best = bids[taskId]!.reduce(min);
    final deal = MetaAgentDeal(
      dealId: 'deal-${DateTime.now().millisecondsSinceEpoch}',
      taskId: taskId,
      participantAgentIds: agents,
      agreedReward: best,
      cryptographicProof: zkp,
      contractHash: contractHash,
    );
    deals.add(deal);
    return deal;
  }

  void markCompleted(String dealId) {
    final deal = deals.firstWhere((d) => d.dealId == dealId);
    deal.isCompleted = true;
  }
}