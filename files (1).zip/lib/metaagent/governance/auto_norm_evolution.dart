class MetaNormProposal {
  final String id;
  final String description;
  int votesFor = 0;
  int votesAgainst = 0;
  final Map<String, double> agentTrustVotes = {};

  MetaNormProposal(this.id, this.description);

  void vote(String agentId, bool accept, double trust) {
    if (accept) {
      votesFor += 1;
      agentTrustVotes[agentId] = trust;
    } else {
      votesAgainst += 1;
      agentTrustVotes[agentId] = -trust;
    }
  }

  double totalWeightedScore() => agentTrustVotes.values.fold(0.0, (a, b) => a + b);
}