import 'dart:collection';

class TrustRecord {
  final String agentId;
  final String action;
  final double deltaTrust;
  final DateTime time;
  TrustRecord(this.agentId, this.action, this.deltaTrust, this.time);
}

class ChainOfTrustLedger {
  final ListQueue<TrustRecord> trustChain = ListQueue();

  void record(String agentId, String action, double deltaTrust) {
    trustChain.add(TrustRecord(agentId, action, deltaTrust, DateTime.now()));
    if (trustChain.length > 1000) trustChain.removeFirst(); // Prune for memory
  }

  double trustScore(String agentId) {
    return trustChain.where((r) => r.agentId == agentId).fold(0.5, (a, b) => (a + b.deltaTrust).clamp(0.0, 1.0));
  }
}