import 'dart:convert';
import 'package:crypto/crypto.dart';

class AssignmentRecord {
  final String taskId;
  final String agentId;
  final double cost;
  final DateTime assignedAt;
  DateTime? completedAt;
  bool success;

  AssignmentRecord({
    required this.taskId,
    required this.agentId,
    required this.cost,
    required this.assignedAt,
    this.completedAt,
    this.success = false,
  });

  Map<String, dynamic> toJson() => {
    'taskId': taskId,
    'agentId': agentId,
    'cost': cost,
    'assignedAt': assignedAt.toIso8601String(),
    'completedAt': completedAt?.toIso8601String(),
    'success': success,
  };
}

class AssignmentLedger {
  final List<AssignmentRecord> records = [];

  void recordAssignment(String taskId, String agentId, double cost) {
    records.add(AssignmentRecord(
      taskId: taskId,
      agentId: agentId,
      cost: cost,
      assignedAt: DateTime.now(),
    ));
  }

  void completeAssignment(String taskId, String agentId, {bool success = true}) {
    final record = records.lastWhere((r) => r.taskId == taskId && r.agentId == agentId);
    record.completedAt = DateTime.now();
    record.success = success;
  }

  String getRootHash() {
    if (records.isEmpty) return '';
    var hash = sha256.convert(utf8.encode(jsonEncode(records.first.toJson()))).toString();
    for (final rec in records.skip(1)) {
      hash = sha256.convert(utf8.encode(hash + jsonEncode(rec.toJson()))).toString();
    }
    return hash;
  }
}