import 'dart:convert';
import 'package:crypto/crypto.dart';

class DAGNode {
  final String hash;
  final Map<String, dynamic> data;
  final List<String> parents;
  DAGNode(this.hash, this.data, this.parents);
}

class DAGLedger {
  final Map<String, DAGNode> nodes = {};

  String addNode(Map<String, dynamic> data, List<String> parentHashes) {
    final raw = jsonEncode({'data': data, 'parents': parentHashes});
    final hash = sha256.convert(utf8.encode(raw)).toString();
    nodes[hash] = DAGNode(hash, data, parentHashes);
    return hash;
  }

  bool verifyNode(String hash) {
    if (!nodes.containsKey(hash)) return false;
    final node = nodes[hash]!;
    final raw = jsonEncode({'data': node.data, 'parents': node.parents});
    return sha256.convert(utf8.encode(raw)).toString() == hash;
  }

  List<DAGNode> get tips =>
      nodes.values.where((n) => nodes.values.every((other) => !other.parents.contains(n.hash))).toList();
}