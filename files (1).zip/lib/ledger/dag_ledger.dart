import 'dart:collection';

class DAGNode {
  final String hash;
  final List<String> parents;
  final Map<String, dynamic> data;
  DAGNode(this.hash, this.parents, this.data);
}

class DAGLedger {
  final Map<String, DAGNode> nodes = {};

  void addNode(DAGNode node) {
    nodes[node.hash] = node;
  }

  List<DAGNode> get tips => nodes.values.where((n) => nodes.values.every((other) => !other.parents.contains(n.hash))).toList();

  // Konsensüs, veri bütünlüğü, DAG traversal vb fonksiyonlar eklenebilir
}