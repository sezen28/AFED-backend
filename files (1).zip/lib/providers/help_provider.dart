import 'package:flutter/material.dart';
import '../models/help_request.dart';
import '../services/help_service.dart';

class HelpProvider with ChangeNotifier {
  final HelpService helpService;
  final String userToken;
  List<HelpRequest> _requests = [];
  bool _loading = false;
  String? _error;

  List<HelpRequest> get requests => _requests;
  bool get loading => _loading;
  String? get error => _error;

  HelpProvider({required this.helpService, required this.userToken});

  Future<void> fetchRequests() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      _requests = await helpService.fetchHelpRequests(userToken);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> addRequest(HelpRequest req) async {
    _loading = true;
    notifyListeners();
    try {
      final created = await helpService.createHelpRequest(userToken, req);
      _requests.insert(0, created);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }
}