import 'package:flutter/material.dart';

class CrisisProvider with ChangeNotifier {
  bool _crisisMode = false;
  bool _energySaving = false;

  bool get crisisMode => _crisisMode;
  bool get energySaving => _energySaving;

  void toggleCrisisMode() {
    _crisisMode = !_crisisMode;
    notifyListeners();
  }

  void setEnergySaving(bool enabled) {
    _energySaving = enabled;
    notifyListeners();
  }
}