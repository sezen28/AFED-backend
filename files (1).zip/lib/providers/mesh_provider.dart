import 'package:flutter/material.dart';
import '../mesh/mesh_message.dart';

class MeshProvider with ChangeNotifier {
  final List<MeshMessage> _messages = [];

  List<MeshMessage> get messages => _messages;

  void addMessage(MeshMessage msg) {
    // duplicate önleme & en yeni versiyonu sakla
    final idx = _messages.indexWhere((e) => e.id == msg.id);
    if (idx >= 0) {
      if (_messages[idx].version < msg.version) {
        _messages[idx] = msg;
        notifyListeners();
      }
    } else {
      _messages.insert(0, msg);
      notifyListeners();
    }
  }
}