import 'package:flutter/material.dart';

class PrivacyProvider with ChangeNotifier {
  bool _privacyMode = false;
  bool get privacyMode => _privacyMode;

  void toggle() {
    _privacyMode = !_privacyMode;
    notifyListeners();
  }
}