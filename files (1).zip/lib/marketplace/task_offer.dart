enum RiskLevel { low, medium, high, critical }

class TaskOffer {
  final String taskId;
  final String requiredSkill;
  final double latitude;
  final double longitude;
  final double urgency;
  final String description;
  final String agentId;
  double cost;
  final RiskLevel risk;
  bool isActive;

  TaskOffer({
    required this.taskId,
    required this.requiredSkill,
    required this.latitude,
    required this.longitude,
    required this.urgency,
    required this.description,
    required this.agentId,
    required this.cost,
    this.risk = RiskLevel.medium,
    this.isActive = true,
  });

  void updateCost(double newCost) {
    cost = newCost;
  }

  void deactivate() {
    isActive = false;
  }
}