class TaskOffer {
  final String agentId;
  final String taskType;
  final double cost;
  TaskOffer(this.agentId, this.taskType, this.cost);
}

class AgentMarketplace {
  final List<TaskOffer> offers = [];

  void submitOffer(TaskOffer offer) => offers.add(offer);

  TaskOffer? selectBest(String taskType) {
    final filtered = offers.where((o) => o.taskType == taskType);
    return filtered.isEmpty ? null : filtered.reduce((a, b) => a.cost < b.cost ? a : b);
  }
}