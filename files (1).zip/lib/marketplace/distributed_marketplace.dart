import '../agent/agent.dart';
import 'task_offer.dart';

class DistributedMarketplace {
  final List<DisasterAgent> agents;
  final List<TaskOffer> offers = [];
  final Set<String> blacklist = {};
  final Set<String> whitelist = {};

  DistributedMarketplace(this.agents);

  void receiveTask(TaskOffer offer) {
    // Blacklist kontrolü
    if (!blacklist.contains(offer.agentId)) {
      offers.add(offer);
    }
  }

  // Birden fazla görev için toplu atama
  Map<String, TaskOffer?> assignAll(List<String> taskIds) {
    final result = <String, TaskOffer?>{};
    for (final taskId in taskIds) {
      result[taskId] = assignBest(taskId);
    }
    return result;
  }

  // En iyi teklifi seçerken puanlama ve whitelist desteği
  TaskOffer? assignBest(String taskId) {
    final candidates = offers
        .where((o) =>
            o.taskId == taskId &&
            o.isActive &&
            !blacklist.contains(o.agentId) &&
            (whitelist.isEmpty || whitelist.contains(o.agentId)))
        .toList();
    if (candidates.isEmpty) return null;
    candidates.sort((a, b) => a.cost.compareTo(b.cost));
    return candidates.first;
  }

  void agentBid(TaskOffer offer) {
    if (agents.any((a) => a.id == offer.agentId && a.canAccept(offer))) {
      receiveTask(offer);
    }
  }

  void withdrawOffer(String agentId, String taskId) {
    offers
        .where((o) => o.agentId == agentId && o.taskId == taskId && o.isActive)
        .forEach((o) => o.deactivate());
  }

  void broadcastToPeers(dynamic message) {
    // Gerçek mesh uygulamasında: meshService.broadcast(message);
  }
}