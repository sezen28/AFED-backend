import 'agent.dart';
import '../marketplace/task_offer.dart';
import '../marketplace/distributed_marketplace.dart';
import 'dart:math';

extension DisasterAgentActions on DisasterAgent {
  TaskOffer proposeForTask(
      String taskId,
      String requiredSkill,
      double lat,
      double lon,
      double urgency,
      String description, {
        RiskLevel risk = RiskLevel.medium,
      }) {
    final distance = _haversine(latitude, longitude, lat, lon);
    final aiScore = _aiScore(requiredSkill, urgency, risk);
    final cost = (1 - energyLevel) + distance / 10 + (1 - trustScore) + (1 - urgency) + (1 - aiScore);
    return TaskOffer(
      taskId: taskId,
      requiredSkill: requiredSkill,
      latitude: lat,
      longitude: lon,
      urgency: urgency,
      description: description,
      agentId: id,
      cost: cost,
      risk: risk,
    );
  }

  void joinMarketplace(DistributedMarketplace market, TaskOffer offer) {
    if (canAccept(offer)) {
      market.agentBid(offer);
    }
  }

  void completeTask(String taskId, DistributedMarketplace market, {bool success = true}) {
    addTaskToHistory(taskId);
    // Başarıya göre güven güncelle
    updateTrust(success ? 0.02 : -0.05);
    // Enerji harcama
    updateEnergy(-0.1);
    // Teklifin güncellenmesi
    market.withdrawOffer(id, taskId);
  }

  double _aiScore(String skill, double urgency, RiskLevel risk) {
    // AI ile: Skor hesapla (örn. Tensorflow modelinden tahmin alınabilir)
    // Burada örnek olarak basit hesap:
    double skillScore = skills.contains(skill) ? 1.0 : 0.5;
    double riskScore = 1.0 - (risk.index * 0.25);
    return skillScore * urgency * riskScore;
  }

  double _haversine(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371;
    final dLat = (lat2 - lat1) * pi / 180;
    final dLon = (lon2 - lon1) * pi / 180;
    final a =
        (sin(dLat / 2) * sin(dLat / 2)) +
        cos(lat1 * pi / 180) *
        cos(lat2 * pi / 180) *
        (sin(dLon / 2) * sin(dLon / 2));
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }
}