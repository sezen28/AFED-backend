enum AgentType { human, drone, robot, iot }

class DisasterAgent {
  final String id;
  final AgentType type;
  double latitude;
  double longitude;
  Set<String> skills;
  double energyLevel;
  double trustScore;
  final List<String> taskHistory = [];

  DisasterAgent({
    required this.id,
    required this.type,
    required this.latitude,
    required this.longitude,
    required this.skills,
    this.energyLevel = 1.0,
    this.trustScore = 0.8,
  });

  bool canAccept(TaskOffer offer) {
    return skills.contains(offer.requiredSkill) && energyLevel > 0.2;
  }

  void updateLocation(double lat, double lon) {
    latitude = lat;
    longitude = lon;
  }

  void updateEnergy(double delta) {
    energyLevel = (energyLevel + delta).clamp(0.0, 1.0);
  }

  void updateTrust(double delta) {
    trustScore = (trustScore + delta).clamp(0.0, 1.0);
  }

  void addSkill(String skill) {
    skills.add(skill);
  }

  void addTaskToHistory(String taskId) {
    taskHistory.add(taskId);
  }

  void sendSignal(String signalType) {
    // Mesh veya p2p ağında uyarı/sinyal yayımı (örn. "yardım lazım", "düşük pil")
    // MeshService().broadcast({'agentId': id, 'signal': signalType, 'loc': [latitude, longitude]});
  }
}