import '../agent/agent.dart';
import '../marketplace/task_offer.dart';
import '../mesh/mesh_service.dart';
import '../ai/agent_ai_score.dart';
import '../security/crypto_service.dart';

class SmartAgentController {
  final DisasterAgent agent;
  final MeshService mesh;
  final AgentAIScorer scorer;
  final CryptoService crypto;
  final String privateKey;
  final String publicKey;

  SmartAgentController(this.agent, this.mesh, this.scorer, this.crypto, this.privateKey, this.publicKey) {
    mesh.onMessage(_onMeshMessage);
  }

  void sendEncryptedSignal(Map<String, dynamic> signal) {
    final msg = signal..addAll({'agentId': agent.id});
    final raw = msg.toString();
    final enc = crypto.encrypt(raw, privateKey);
    final sig = crypto.sign(raw, privateKey);
    mesh.broadcast({
      "payload": enc,
      "signature": sig,
      "publicKey": publicKey,
    });
  }

  void _onMeshMessage(Map<String, dynamic> message) {
    // Mesajı doğrula ve çözümler
    if (message.containsKey("payload") && message.containsKey("signature") && message.containsKey("publicKey")) {
      final payload = message["payload"];
      final sig = message["signature"];
      final pubKey = message["publicKey"];
      final decrypted = crypto.decrypt(payload, pubKey);
      if (crypto.verify(decrypted, sig, pubKey)) {
        print("[${agent.id}] Gelen şifreli mesh mesajı: $decrypted");
        // Burada AI ile görev skoru ve karar entegrasyonu yapılabilir.
      }
    }
  }

  double evaluateTask(TaskOffer offer) {
    return scorer.score(agent, offer);
  }
}