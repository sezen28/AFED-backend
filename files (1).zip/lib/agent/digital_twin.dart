class DigitalTwin {
  final String originAgentId;
  final Map<String, dynamic> state;
  DigitalTwin(this.originAgentId, this.state);

  void handoverTo(String newAgentId) {
    print("Digital twin of $originAgentId handed over to $newAgentId");
  }
}