import 'dart:async';

abstract class DisasterAgent {
  final String id;
  DisasterAgent(this.id);

  Future<void> onMessage(Map<String, dynamic> msg);
  Future<void> act();
}

class AgentCouncil {
  final List<DisasterAgent> agents = [];

  void register(DisasterAgent agent) => agents.add(agent);

  Future<void> broadcast(Map<String, dynamic> msg) async {
    for (final agent in agents) {
      await agent.onMessage(msg);
    }
  }

  Future<void> runAll() async {
    for (final agent in agents) {
      await agent.act();
    }
  }
}