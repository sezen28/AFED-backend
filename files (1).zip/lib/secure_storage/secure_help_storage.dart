import 'package:hive/hive.dart';
import '../models/help_request.dart';
import '../utils/encryption_utils.dart';

class SecureHelpStorage {
  static const boxKey = 'secure_help_requests';

  static Future<void> addEncrypted(HelpRequest req) async {
    final box = await Hive.openBox<String>(boxKey); // Şifreli string olarak sakla
    final encData = await EncryptionUtils.encrypt(req.toJson().toString());
    await box.put(req.id, encData);
  }

  static Future<HelpRequest?> getDecrypted(String id) async {
    final box = await Hive.openBox<String>(boxKey);
    final encData = box.get(id);
    if (encData == null) return null;
    final jsonStr = await EncryptionUtils.decrypt(encData);
    return HelpRequest.fromJson(jsonStr as Map<String, dynamic>);
  }
}