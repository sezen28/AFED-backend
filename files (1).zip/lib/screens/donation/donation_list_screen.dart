import 'package:flutter/material.dart';
import '../../models/donation.dart';
import '../../services/donation_service.dart';

class DonationListScreen extends StatefulWidget {
  @override
  State<DonationListScreen> createState() => _DonationListScreenState();
}

class _DonationListScreenState extends State<DonationListScreen> {
  late Future<List<Donation>> _futureDonations;

  @override
  void initState() {
    super.initState();
    _futureDonations = DonationService().fetchDonations();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bağışlar')),
      body: FutureBuilder<List<Donation>>(
        future: _futureDonations,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Bağış yok'));
          }
          final donations = snapshot.data!;
          return ListView.builder(
            itemCount: donations.length,
            itemBuilder: (context, i) => Card(
              child: ListTile(
                title: Text(donations[i].type),
                subtitle: Text(donations[i].amount != null
                    ? '${donations[i].amount} ₺'
                    : donations[i].description ?? ''),
                onTap: () {
                  // Detay ekranına git
                },
              ),
            ),
          );
        },
      ),
    );
  }
}