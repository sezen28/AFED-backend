import 'package:flutter/material.dart';
import '../../models/notification.dart';
import '../../services/notification_service.dart';

class NotificationListScreen extends StatefulWidget {
  @override
  State<NotificationListScreen> createState() => _NotificationListScreenState();
}

class _NotificationListScreenState extends State<NotificationListScreen> {
  late Future<List<NotificationMessage>> _futureNotifications;

  @override
  void initState() {
    super.initState();
    _futureNotifications = NotificationService().fetchNotifications();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Bildirimler')),
      body: FutureBuilder<List<NotificationMessage>>(
        future: _futureNotifications,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Bildirim yok'));
          }
          final notifications = snapshot.data!;
          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, i) => Card(
              child: ListTile(
                title: Text(notifications[i].title),
                subtitle: Text(notifications[i].content),
                trailing: notifications[i].isRead
                    ? null
                    : Icon(Icons.fiber_new_rounded, color: Colors.red),
                onTap: () {
                  // Bildirim detay veya okundu olarak işaretle
                },
              ),
            ),
          );
        },
      ),
    );
  }
}