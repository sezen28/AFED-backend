import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/help_request.dart';
import '../../providers/help_provider.dart';

class HelpFormScreen extends StatefulWidget {
  @override
  State<HelpFormScreen> createState() => _HelpFormScreenState();
}

class _HelpFormScreenState extends State<HelpFormScreen> {
  final _formKey = GlobalKey<FormState>();
  String description = "";
  String priority = "med";
  double latitude = 0.0;
  double longitude = 0.0;

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<HelpProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(title: Text('Yeni Yardım Talebi')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: "Açıklama"),
                minLines: 2,
                maxLines: 5,
                validator: (v) =>
                    v == null || v.isEmpty ? "Açıklama zorunlu" : null,
                onSaved: (v) => description = v ?? "",
              ),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(labelText: "Öncelik"),
                value: priority,
                items: [
                  DropdownMenuItem(value: "low", child: Text("Düşük")),
                  DropdownMenuItem(value: "med", child: Text("Orta")),
                  DropdownMenuItem(value: "high", child: Text("Yüksek")),
                  DropdownMenuItem(value: "crit", child: Text("Kritik")),
                ],
                onChanged: (v) => setState(() => priority = v ?? "med"),
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Enlem (Lat)"),
                keyboardType: TextInputType.number,
                onSaved: (v) =>
                    latitude = double.tryParse(v ?? "") ?? 0.0,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Boylam (Lon)"),
                keyboardType: TextInputType.number,
                onSaved: (v) =>
                    longitude = double.tryParse(v ?? "") ?? 0.0,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                child: Text("Kaydet"),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    final req = HelpRequest(
                      id: '', // Backend oluşturacak!
                      userId: 'me', // Giriş yapan kullanıcı
                      description: description,
                      status: 'open',
                      priority: priority,
                      latitude: latitude,
                      longitude: longitude,
                      files: [],
                      createdAt: DateTime.now(),
                      updatedAt: DateTime.now(),
                      version: 1,
                      isActive: true,
                      shelterId: null,
                      disasterId: null,
                    );
                    provider.addRequest(req).then((_) {
                      Navigator.pop(context);
                    });
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}