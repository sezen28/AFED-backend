import 'package:flutter/material.dart';
import '../../mesh/mesh_message.dart';
import '../../mesh/mesh_service.dart';
import '../../models/help_request.dart';
import '../../utils/crypto_utils.dart'; // public/private key & sign/verify

class HelpFormMeshScreen extends StatefulWidget {
  @override
  State<HelpFormMeshScreen> createState() => _HelpFormMeshScreenState();
}

class _HelpFormMeshScreenState extends State<HelpFormMeshScreen> {
  final _formKey = GlobalKey<FormState>();
  String description = "";
  String priority = "med";
  double latitude = 0.0;
  double longitude = 0.0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mesh ile Yardım Talebi')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: "Açıklama"),
                minLines: 2,
                maxLines: 5,
                validator: (v) =>
                    v == null || v.isEmpty ? "Açıklama zorunlu" : null,
                onSaved: (v) => description = v ?? "",
              ),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(labelText: "Öncelik"),
                value: priority,
                items: [
                  DropdownMenuItem(value: "low", child: Text("Düşük")),
                  DropdownMenuItem(value: "med", child: Text("Orta")),
                  DropdownMenuItem(value: "high", child: Text("Yüksek")),
                  DropdownMenuItem(value: "crit", child: Text("Kritik")),
                ],
                onChanged: (v) => setState(() => priority = v ?? "med"),
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Enlem (Lat)"),
                keyboardType: TextInputType.number,
                onSaved: (v) => latitude = double.tryParse(v ?? "") ?? 0.0,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Boylam (Lon)"),
                keyboardType: TextInputType.number,
                onSaved: (v) => longitude = double.tryParse(v ?? "") ?? 0.0,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                child: Text("Mesh ile Gönder"),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    final req = HelpRequest(
                      id: UniqueKey().toString(),
                      userId: 'me',
                      description: description,
                      status: 'open',
                      priority: priority,
                      latitude: latitude,
                      longitude: longitude,
                      files: [],
                      createdAt: DateTime.now(),
                      updatedAt: DateTime.now(),
                      version: 1,
                      isActive: true,
                      shelterId: null,
                      disasterId: null,
                    );
                    final jsonPayload = jsonEncode(req.toJson());
                    final myPubKey = await CryptoUtils.getMyPublicKey();
                    final signature = await CryptoUtils.sign(jsonPayload);
                    final meshMsg = MeshMessage(
                      id: req.id,
                      type: "help",
                      payload: jsonPayload, // isteğe bağlı: şifreli de olabilir
                      senderPublicKey: myPubKey,
                      signature: signature,
                      version: req.version,
                      timestamp: req.createdAt,
                    );
                    MeshService().send(meshMsg);
                    Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}