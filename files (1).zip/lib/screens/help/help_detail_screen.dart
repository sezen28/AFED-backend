import 'package:flutter/material.dart';
import '../../models/help_request.dart';

class HelpDetailScreen extends StatelessWidget {
  final HelpRequest request;

  const HelpDetailScreen({required this.request});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Talep Detayı'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ListTile(
              leading: Icon(Icons.description),
              title: Text("Açıklama"),
              subtitle: Text(request.description),
            ),
            ListTile(
              leading: Icon(Icons.warning),
              title: Text("Durum"),
              subtitle: Text(request.status),
            ),
            ListTile(
              leading: Icon(Icons.priority_high),
              title: Text("Öncelik"),
              subtitle: Text(request.priority),
            ),
            ListTile(
              leading: Icon(Icons.location_on),
              title: Text("Konum"),
              subtitle:
                  Text("Lat: ${request.latitude}, Lon: ${request.longitude}"),
            ),
            ListTile(
              leading: Icon(Icons.date_range),
              title: Text("Oluşturulma"),
              subtitle: Text(request.createdAt.toString()),
            ),
            if (request.files != null && request.files!.isNotEmpty)
              ExpansionTile(
                leading: Icon(Icons.attach_file),
                title: Text("Dosyalar"),
                children: request.files!
                    .map((f) => ListTile(
                          title: Text(f),
                        ))
                    .toList(),
              ),
          ],
        ),
      ),
    );
  }
}