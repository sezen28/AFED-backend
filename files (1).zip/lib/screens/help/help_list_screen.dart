// ...
itemBuilder: (context, i) {
  final req = provider.requests[i];
  final isMesh = meshProvider.messages.any((m) => m.id == req.id);
  return Card(
    color: isMesh ? Colors.purple.shade100 : null,
    child: ListTile(
      leading: isMesh ? Icon(Icons.wifi_tethering, color: Colors.purple) : null,
      title: Text(req.description),
      subtitle: Text('Mesh: ${isMesh ? "Evet" : "Hayır"}'),
      // ...
    ),
  );
},
// ...