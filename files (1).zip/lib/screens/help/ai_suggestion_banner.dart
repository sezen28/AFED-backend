import 'package:flutter/material.dart';
import '../../models/help_request.dart';

class AISuggestionBanner extends StatelessWidget {
  final HelpRequest? suggestion;
  const AISuggestionBanner({this.suggestion});

  @override
  Widget build(BuildContext context) {
    if (suggestion == null) return SizedBox.shrink();
    return Container(
      color: Colors.green.shade100,
      padding: EdgeInsets.all(12),
      child: Row(
        children: [
          Icon(Icons.smart_toy, color: Colors.green),
          SizedBox(width: 8),
          Expanded(child: Text('AI: En acil yardım noktası "${suggestion!.description}"')),
          Icon(Icons.arrow_forward, color: Colors.green),
        ],
      ),
    );
  }
}