import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/crisis_provider.dart';
import '../services/battery_service.dart';
import 'help/help_list_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _checkBattery();
  }

  Future<void> _checkBattery() async {
    if (await BatteryService.isLow()) {
      final crisis = Provider.of<CrisisProvider>(context, listen: false);
      crisis.setEnergySaving(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final crisis = Provider.of<CrisisProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Afet Uygulaması'),
        actions: [
          IconButton(
            icon: Icon(
              crisis.crisisMode ? Icons.warning : crisis.energySaving ? Icons.battery_alert : Icons.bolt,
              color: crisis.crisisMode
                  ? Colors.red
                  : crisis.energySaving
                      ? Colors.orange
                      : Colors.green,
            ),
            onPressed: () => crisis.toggleCrisisMode(),
            tooltip: "Kriz/Tasarruf Modu",
          ),
        ],
      ),
      body: Column(
        children: [
          if (crisis.crisisMode)
            Container(
              color: Colors.red.shade100,
              padding: EdgeInsets.all(8),
              child: Row(
                children: [
                  Icon(Icons.warning, color: Colors.red),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      "KRİZ MODU AKTİF! Uygulama minimum enerji ve veriyle çalışıyor.",
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                    ),
                  ),
                ],
              ),
            ),
          if (crisis.energySaving && !crisis.crisisMode)
            Container(
              color: Colors.orange.shade100,
              padding: EdgeInsets.all(8),
              child: Row(
                children: [
                  Icon(Icons.battery_alert, color: Colors.orange),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      "Enerji Tasarruf Modu: Pil düşük, uygulama optimizasyon yaptı.",
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange),
                    ),
                  ),
                ],
              ),
            ),
          Expanded(child: HelpListScreen()),
        ],
      ),
    );
  }
}