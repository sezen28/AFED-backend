import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:mbtiles/mbtiles.dart';
import 'package:geolocator/geolocator.dart';
import '../../models/shelter.dart';
import '../../services/shelter_service.dart';

class OfflineShelterMapScreen extends StatefulWidget {
  @override
  _OfflineShelterMapScreenState createState() => _OfflineShelterMapScreenState();
}

class _OfflineShelterMapScreenState extends State<OfflineShelterMapScreen> {
  late MBTilesImageProvider tileProvider;
  List<Shelter> shelters = [];
  LatLng? userLocation;

  @override
  void initState() {
    super.initState();
    tileProvider = MBTilesImageProvider('assets/maps/city.mbtiles'); // MBTiles dosyanızın yolu
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedShelters = await ShelterService().fetchShelters();
    final position = await _getLocation();
    setState(() {
      shelters = loadedShelters;
      userLocation = position != null ? LatLng(position.latitude, position.longitude) : null;
    });
  }

  Future<Position?> _getLocation() async {
    try {
      return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      if (userLocation != null)
        Marker(
          width: 40,
          height: 40,
          point: userLocation!,
          builder: (_) => Icon(Icons.person_pin_circle, color: Colors.blue, size: 40),
        ),
      ...shelters.map(
        (s) => Marker(
          width: 36,
          height: 36,
          point: LatLng(s.latitude, s.longitude),
          builder: (_) => Tooltip(
            message: s.name,
            child: Icon(Icons.home_work, color: Colors.green, size: 32),
          ),
        ),
      ),
    ];

    return Scaffold(
      appBar: AppBar(title: Text("Offline Barınak Haritası")),
      body: FlutterMap(
        options: MapOptions(
          center: userLocation ?? (shelters.isNotEmpty
              ? LatLng(shelters[0].latitude, shelters[0].longitude)
              : LatLng(39.9, 32.85)), // Türkiye ortası fallback
          zoom: 12,
        ),
        children: [
          TileLayer(
            tileProvider: tileProvider,
            maxZoom: 18,
            minZoom: 6,
          ),
          MarkerLayer(markers: markers),
        ],
      ),
      floatingActionButton: userLocation == null
          ? null
          : FloatingActionButton.extended(
              icon: Icon(Icons.near_me),
              label: Text("En Yakın Barınak"),
              onPressed: () {
                // En yakın barınağı bul ve bilgi göster
                final nearest = _findNearestShelter(userLocation!, shelters);
                if (nearest != null) {
                  final dist = Distance().as(
                    LengthUnit.Kilometer,
                    userLocation!,
                    LatLng(nearest.latitude, nearest.longitude),
                  );
                  showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                            title: Text("En Yakın Barınak"),
                            content: Text(
                              "${nearest.name}\n${nearest.city}\nMesafe: ${dist.toStringAsFixed(2)} km",
                            ),
                          ));
                }
              },
            ),
    );
  }

  Shelter? _findNearestShelter(LatLng user, List<Shelter> shelters) {
    if (shelters.isEmpty) return null;
    Shelter? nearest;
    double minDist = double.infinity;
    for (final s in shelters) {
      final d = Distance().as(LengthUnit.Kilometer, user, LatLng(s.latitude, s.longitude));
      if (d < minDist) {
        minDist = d;
        nearest = s;
      }
    }
    return nearest;
  }
}