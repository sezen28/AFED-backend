import 'package:flutter/material.dart';
import '../../models/alert.dart';
import '../../services/alert_service.dart';

class AlertListScreen extends StatefulWidget {
  @override
  State<AlertListScreen> createState() => _AlertListScreenState();
}

class _AlertListScreenState extends State<AlertListScreen> {
  late Future<List<Alert>> _futureAlerts;

  @override
  void initState() {
    super.initState();
    _futureAlerts = AlertService().fetchAlerts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Uyarılar')),
      body: FutureBuilder<List<Alert>>(
        future: _futureAlerts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Uyarı yok'));
          }
          final alerts = snapshot.data!;
          return ListView.builder(
            itemCount: alerts.length,
            itemBuilder: (context, i) => Card(
              color: alerts[i].riskLevel == 'high' ? Colors.red[100] : null,
              child: ListTile(
                title: Text(alerts[i].title),
                subtitle: Text('${alerts[i].type} • ${alerts[i].riskLevel}'),
                trailing: Icon(Icons.warning),
                onTap: () {
                  // Detay ekranına git
                },
              ),
            ),
          );
        },
      ),
    );
  }
}