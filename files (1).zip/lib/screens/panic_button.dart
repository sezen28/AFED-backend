import 'package:flutter/material.dart';
import '../zero_trust/identity_service.dart';

class PanicButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.red,
      tooltip: "Panik Modu: Tüm veriyi imha et",
      child: Icon(Icons.delete_forever),
      onPressed: () async {
        // Tüm anahtarları, şifreli storage'ı, local mesh havuzunu ve geçmişi temizle
        await IdentityService().generateDID(); // Eski anahtarı sil, yeni oluştur
        // Ek olarak secure storage ve cache temizlenir
        // Kalan veri üzerine random data yazılır (anti-forensics)
        // UI'da bilgi ver
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tüm hassas veriler silindi!')));
      },
    );
  }
}