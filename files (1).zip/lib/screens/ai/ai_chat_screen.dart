import 'package:flutter/material.dart';
import '../../models/ai_message.dart';
import '../../services/ai_service.dart';

class AIChatScreen extends StatefulWidget {
  @override
  State<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends State<AIChatScreen> {
  final List<AIMessage> messages = [];
  final TextEditingController controller = TextEditingController();
  bool sending = false;

  void sendMessage() async {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add(AIMessage(
        id: '',
        message: text,
        isUser: true,
        createdAt: DateTime.now(),
      ));
      sending = true;
    });
    controller.clear();
    // AIService: OpenAI/chatbot API ile konuşma
    final aiMsg = await AIService().sendMessage(text);
    setState(() {
      messages.add(aiMsg);
      sending = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('AI Yardım')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, i) => Align(
                alignment:
                    messages[i].isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Card(
                  color: messages[i].isUser ? Colors.blue[100] : Colors.grey[300],
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(messages[i].message),
                  ),
                ),
              ),
            ),
          ),
          if (sending) LinearProgressIndicator(),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  onSubmitted: (_) => sendMessage(),
                  decoration: InputDecoration(
                    hintText: "Mesajınızı yazın...",
                  ),
                ),
              ),
              IconButton(
                icon: Icon(Icons.send),
                onPressed: sendMessage,
              )
            ],
          ),
        ],
      ),
    );
  }
}