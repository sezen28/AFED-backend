import 'package:flutter/material.dart';
import '../../models/shelter.dart';
import '../../services/shelter_service.dart';

class ShelterListScreen extends StatefulWidget {
  @override
  State<ShelterListScreen> createState() => _ShelterListScreenState();
}

class _ShelterListScreenState extends State<ShelterListScreen> {
  late Future<List<Shelter>> _futureShelters;

  @override
  void initState() {
    super.initState();
    _futureShelters = ShelterService().fetchShelters();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Barınaklar')),
      body: FutureBuilder<List<Shelter>>(
        future: _futureShelters,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Bir hata oluştu'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Barınak yok'));
          }
          final shelters = snapshot.data!;
          return ListView.builder(
            itemCount: shelters.length,
            itemBuilder: (context, i) => Card(
              child: ListTile(
                title: Text(shelters[i].name),
                subtitle: Text('${shelters[i].city} • Kapasite: ${shelters[i].capacity}'),
                onTap: () {
                  // Detay ekranına git
                },
              ),
            ),
          );
        },
      ),
    );
  }
}