import 'dart:convert';
import 'package:crypto/crypto.dart';

class MerkleNode {
  final String hash;
  final MerkleNode? left;
  final MerkleNode? right;

  MerkleNode(this.hash, [this.left, this.right]);
}

class MerkleNetService {
  List<String> dataHashes = [];

  void addData(String data) {
    dataHashes.add(sha256.convert(utf8.encode(data)).toString());
  }

  MerkleNode buildTree() {
    List<MerkleNode> nodes = dataHashes.map((h) => MerkleNode(h)).toList();
    while (nodes.length > 1) {
      final next = <MerkleNode>[];
      for (int i = 0; i < nodes.length; i += 2) {
        if (i + 1 < nodes.length) {
          final combined = nodes[i].hash + nodes[i + 1].hash;
          final hash = sha256.convert(utf8.encode(combined)).toString();
          next.add(MerkleNode(hash, nodes[i], nodes[i + 1]));
        } else {
          next.add(nodes[i]);
        }
      }
      nodes = next;
    }
    return nodes.first;
  }

  String getRoot() => buildTree().hash;
}