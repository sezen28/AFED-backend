import 'package:meshkit/meshkit.dart'; // örnek mesh paketi
import 'package:matrix/matrix.dart';   // Matrix protokolü için
import 'package:bridgefy_flutter/bridgefy_flutter.dart';

class MultiMeshService {
  void startAll() {
    MeshKit().start(); // Wi-Fi Direct/Bluetooth Mesh
    BridgefyFlutter.start(); // Bridgefy
    // Matrix SDK ile merkeziyetsiz chat odası açmak
    // MatrixClient().loginWithAccessToken(...) ...
  }

  void sendToAll(String message) {
    MeshKit().sendBroadcast(message);
    BridgefyFlutter.sendBroadcastMessage(message);
    // MatrixClient().sendMessage(...)
  }
}