import 'dart:convert';

class MeshMessage {
  final String id;
  final String type; // "help", "alert", "chat"
  final String payload; // JSON string (şifreli)
  final String senderPublicKey;
  final String signature;
  final int version;
  final DateTime timestamp;

  MeshMessage({
    required this.id,
    required this.type,
    required this.payload,
    required this.senderPublicKey,
    required this.signature,
    required this.version,
    required this.timestamp,
  });

  factory MeshMessage.fromJson(Map<String, dynamic> json) => MeshMessage(
        id: json['id'],
        type: json['type'],
        payload: json['payload'],
        senderPublicKey: json['senderPublicKey'],
        signature: json['signature'],
        version: json['version'],
        timestamp: DateTime.parse(json['timestamp']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'payload': payload,
        'senderPublicKey': senderPublicKey,
        'signature': signature,
        'version': version,
        'timestamp': timestamp.toIso8601String(),
      };
}