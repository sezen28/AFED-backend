import '../agent/agent.dart';
import '../marketplace/distributed_marketplace.dart';
import '../marketplace/task_offer.dart';
import '../agent/agent_actions.dart';

void simulateDistributedTaskAssignment() {
  final agents = [
    DisasterAgent(id: "A1", type: AgentType.human, latitude: 39.9, longitude: 32.8, skills: {"rescue", "medical"}, energyLevel: 0.8, trustScore: 0.9),
    DisasterAgent(id: "D1", type: AgentType.drone, latitude: 39.92, longitude: 32.81, skills: {"delivery"}, energyLevel: 0.6, trustScore: 0.85),
    DisasterAgent(id: "R1", type: AgentType.robot, latitude: 39.91, longitude: 32.82, skills: {"rescue"}, energyLevel: 0.7, trustScore: 0.95),
  ];
  final market = DistributedMarketplace(agents);

  final tasks = [
    {
      "taskId": "TASK-101",
      "requiredSkill": "rescue",
      "urgency": 0.95,
      "lat": 39.915,
      "lon": 32.815,
      "desc": "Enkazda mahsur kalan var!",
      "risk": RiskLevel.critical,
    },
    {
      "taskId": "TASK-102",
      "requiredSkill": "delivery",
      "urgency": 0.8,
      "lat": 39.920,
      "lon": 32.810,
      "desc": "İlk yardım çantası taşınacak.",
      "risk": RiskLevel.medium,
    },
  ];

  // Agent’lar otonomca teklif oluşturup pazara sunuyor
  for (final task in tasks) {
    for (final agent in agents) {
      final offer = agent.proposeForTask(
        task["taskId"] as String,
        task["requiredSkill"] as String,
        task["lat"] as double,
        task["lon"] as double,
        task["urgency"] as double,
        task["desc"] as String,
        risk: task["risk"] as RiskLevel,
      );
      agent.joinMarketplace(market, offer);
    }
  }

  // Marketplace tüm görevleri dağıtır
  final assignments = market.assignAll(tasks.map((t) => t["taskId"] as String).toList());
  assignments.forEach((taskId, offer) {
    if (offer != null) {
      print("Görev '$taskId' atandı: Agent ${offer.agentId} [cost: ${offer.cost.toStringAsFixed(2)}, risk: ${offer.risk}]");
      // Görev tamamlanınca agent feedback verir
      final agent = agents.firstWhere((a) => a.id == offer.agentId);
      agent.completeTask(taskId, market, success: true);
    } else {
      print("Görev '$taskId' için uygun agent bulunamadı!");
    }
  });
}