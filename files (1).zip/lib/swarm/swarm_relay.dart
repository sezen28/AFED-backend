import '../agent/agent.dart';
import '../marketplace/task_offer.dart';

class SwarmRelay {
  // Aktif görevdeki agent'ın görevini başka bir agent'a devretmesi
  static bool relayTask(DisasterAgent from, DisasterAgent to, TaskOffer offer) {
    if (to.canAccept(offer)) {
      print("Görev ${offer.taskId} agent ${from.id}’den agent ${to.id}’ye devredildi.");
      return true;
    }
    return false;
  }
}