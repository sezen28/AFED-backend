import 'dart:async';
import 'package:meshkit/meshkit.dart';

class SelfHealingBeacon {
  final MeshKit meshKit = MeshKit();
  Timer? _timer;

  void startBeacon() {
    _timer = Timer.periodic(Duration(seconds: 30), (_) async {
      final neighbors = await meshKit.getNeighbors();
      if (neighbors.isEmpty) {
        // Broadcast beacon, “alive” uyarısı için
        meshKit.sendBroadcast('{"type":"beacon","timestamp":${DateTime.now().millisecondsSinceEpoch}}');
      }
    });
  }

  void stopBeacon() {
    _timer?.cancel();
  }
}