import 'package:flutter/material.dart';
import '../models/help_request.dart';

Future<void> showHelpRequestConflictDialog(
  BuildContext context,
  HelpRequest local,
  HelpRequest remote,
  void Function(HelpRequest resolved) onResolved,
) async {
  await showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: Text("Çakışma Tespit Edildi"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Aynı yardım talebinde hem siz hem sistemde değişiklik var."),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: Text("Sizinki:", style: TextStyle(fontWeight: FontWeight.bold))),
              Expanded(child: Text("Sunucu:", style: TextStyle(fontWeight: FontWeight.bold))),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.description)),
              Expanded(child: Text(remote.description)),
            ],
          ),
          Row(
            children: [
              Expanded(child: Text(local.status)),
              Expanded(child: Text(remote.status)),
            ],
          ),
          SizedBox(height: 16),
          Text("Hangisini saklamak istersiniz?"),
        ],
      ),
      actions: [
        TextButton(
          child: Text("Benimki"),
          onPressed: () {
            onResolved(local);
            Navigator.pop(context);
          },
        ),
        TextButton(
          child: Text("Sunucudaki"),
          onPressed: () {
            onResolved(remote);
            Navigator.pop(context);
          },
        ),
        TextButton(
          child: Text("Birleştir"),
          onPressed: () {
            final merged = HelpRequest(
              id: local.id,
              userId: local.userId,
              shelterId: local.shelterId,
              disasterId: local.disasterId,
              description: local.description + "\n---\n" + remote.description,
              status: local.status == remote.status ? local.status : "${local.status} / ${remote.status}",
              priority: local.priority,
              latitude: local.latitude,
              longitude: local.longitude,
              files: {...?local.files, ...?remote.files}.toList(),
              createdAt: local.createdAt,
              updatedAt: DateTime.now(),
              version: remote.version + 1,
              isActive: local.isActive,
            );
            onResolved(merged);
            Navigator.pop(context);
          },
        ),
      ],
    ),
  );
}