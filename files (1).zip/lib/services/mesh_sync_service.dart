import '../mesh/mesh_message.dart';
import '../services/help_service.dart';

class MeshSyncService {
  final HelpService helpService;
  final String token;

  MeshSyncService(this.helpService, this.token);

  Future<void> syncToBackend(List<MeshMessage> meshMessages) async {
    for (final msg in meshMessages) {
      if (msg.type == "help") {
        final helpReq = HelpRequest.fromJson(jsonDecode(msg.payload));
        await helpService.createHelpRequest(token, helpReq);
        // Sunucuya gönderilen mesh mesajlarını işaretle (örn. local flag)
      }
    }
  }
}