import 'package:latlong2/latlong.dart';
import '../../models/help_request.dart';

class AIRoutingService {
  HelpRequest? findBestRequest(LatLng userLoc, List<HelpRequest> requests, List<double> priorities) {
    if (requests.isEmpty) return null;
    double minScore = double.infinity;
    HelpRequest? best;
    for (int i = 0; i < requests.length; i++) {
      final dist = Distance().as(LengthUnit.Kilometer, userLoc, LatLng(requests[i].latitude, requests[i].longitude));
      // Skor: öncelik*2 + mesafe
      final score = priorities[i] * 2 + dist;
      if (score < minScore) {
        minScore = score;
        best = requests[i];
      }
    }
    return best;
  }
}