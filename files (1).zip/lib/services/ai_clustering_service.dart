import 'package:ml_algo/ml_algo.dart'; // KMeans örneği için
import '../../models/help_request.dart';

class AIClusteringService {
  // Her yardım talebinin koordinatıyla kümeler bul
  List<int> clusterRequests(List<HelpRequest> requests, int k) {
    final data = requests
        .map((r) => [r.latitude, r.longitude])
        .toList(growable: false);
    final kmeans = KMeans(
      data,
      k: k,
      seed: 12,
    );
    return kmeans.predict(data).toList();
  }
}