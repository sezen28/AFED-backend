import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/help_request.dart';

class HelpService {
  final String baseUrl = "https://api.afetapp.com"; // Değiştirin

  Future<List<HelpRequest>> fetchHelpRequests(String token, {DateTime? since}) async {
    final url = since == null
        ? "$baseUrl/help-requests"
        : "$baseUrl/help-requests?since=${since.toUtc().toIso8601String()}";
    final response = await http.get(
      Uri.parse(url),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((json) => HelpRequest.fromJson(json)).toList();
    } else {
      throw Exception('Yardım talepleri alınamadı');
    }
  }

  Future<HelpRequest> createHelpRequest(String token, HelpRequest request) async {
    final response = await http.post(
      Uri.parse("$baseUrl/help-requests"),
      headers: {"Authorization": "Bearer $token", "Content-Type": "application/json"},
      body: jsonEncode(request.toJson()),
    );
    if (response.statusCode == 200 || response.statusCode == 201) {
      return HelpRequest.fromJson(json.decode(response.body));
    } else {
      throw Exception('Yardım talebi oluşturulamadı');
    }
  }

  Future<HelpRequest> getHelpRequest(String token, String id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/help-requests/$id"),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      return HelpRequest.fromJson(json.decode(response.body));
    } else {
      throw Exception('Yardım talebi getirilemedi');
    }
  }
}