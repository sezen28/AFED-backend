import 'package:tflite_flutter/tflite_flutter.dart';

class AIPriorityService {
  late Interpreter _interpreter;

  Future<void> loadModel() async {
    _interpreter = await Interpreter.fromAsset('priority_model.tflite');
  }

  // Örnek olarak: [latitude, longitude, saat, açıklama_vektörü, vs.]
  double predictPriority(List<double> features) {
    var input = [features];
    var output = List.filled(1, 0.0).reshape([1, 1]);
    _interpreter.run(input, output);
    return output[0][0];
  }
}