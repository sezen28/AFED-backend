// ...
FirebaseMessaging.onMessage.listen((RemoteMessage message) {
  final notification = message.notification;
  final privacyMode = Provider.of<PrivacyProvider>(context, listen: false).privacyMode;
  final body = privacyMode ? "Yeni uyarınız var. İçerik gizli." : notification?.body;
  if (notification != null) {
    localNotifications.show(
      notification.hashCode,
      notification.title,
      body,
      // ...
    );
  }
});
// ...