import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user.dart';

class UserService {
  final String baseUrl = "https://api.afetapp.com";

  Future<User> getUser(String token, String id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/users/$id"),
      headers: {"Authorization": "Bearer $token"},
    );
    if (response.statusCode == 200) {
      return User.fromJson(json.decode(response.body));
    }
    throw Exception('Failed to fetch user');
  }
}