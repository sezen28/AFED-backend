import 'dart:io';
import '../queue/help_queue.dart';
import '../services/help_service.dart';
import '../models/help_request.dart';

class SyncService {
  final HelpService helpService;
  final String token;

  SyncService(this.helpService, this.token);

  Future<void> syncHelpRequests(Function(HelpRequest local, HelpRequest remote, void Function(HelpRequest) resolve)? onConflict) async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isEmpty) return;
      final queue = await HelpQueue.getQueue();
      for (var i = queue.length - 1; i >= 0; i--) {
        try {
          // Sunucuda mevcut mu?
          final serverReq = await helpService.getHelpRequest(token, queue[i].id);
          if (serverReq.version == queue[i].version) {
            // Çakışma yok, push et
            await helpService.createHelpRequest(token, queue[i]);
            await HelpQueue.removeFromQueue(i);
          } else {
            // Çakışma: kullanıcıya çözdür
            if (onConflict != null) {
              await onConflict(queue[i], serverReq, (resolved) async {
                await helpService.createHelpRequest(token, resolved);
                await HelpQueue.removeFromQueue(i);
              });
            }
          }
        } catch (e) {
          // Sunucuda yoksa yeni kayıt gibi push et
          await helpService.createHelpRequest(token, queue[i]);
          await HelpQueue.removeFromQueue(i);
        }
      }
    } catch (_) {}
  }
}