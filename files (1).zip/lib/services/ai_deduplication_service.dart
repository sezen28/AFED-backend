import 'package:string_similarity/string_similarity.dart';
import '../../models/help_request.dart';

class AIDeduplicationService {
  List<HelpRequest> deduplicate(List<HelpRequest> requests) {
    final result = <HelpRequest>[];
    for (var req in requests) {
      final isDuplicate = result.any((other) =>
          StringSimilarity.compareTwoStrings(req.description, other.description) > 0.8 &&
          (req.latitude - other.latitude).abs() < 0.001 &&
          (req.longitude - other.longitude).abs() < 0.001);
      if (!isDuplicate) result.add(req);
    }
    return result;
  }
}