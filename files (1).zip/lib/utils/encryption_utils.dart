import 'dart:convert';
import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class EncryptionUtils {
  static const _keyStorageKey = 'aes_key';
  static final _secureStorage = FlutterSecureStorage();

  // Anahtar oluştur veya getir
  static Future<enc.Key> getKey() async {
    String? base64Key = await _secureStorage.read(key: _keyStorageKey);
    if (base64Key == null) {
      final key = enc.Key.fromSecureRandom(32);
      await _secureStorage.write(key: _keyStorageKey, value: base64.encode(key.bytes));
      return key;
    } else {
      return enc.Key(base64.decode(base64Key));
    }
  }

  static Future<String> encrypt(String plainText) async {
    final key = await getKey();
    final iv = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key));
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    return base64.encode(iv.bytes) + ':' + encrypted.base64;
  }

  static Future<String> decrypt(String cipherText) async {
    final key = await getKey();
    final parts = cipherText.split(':');
    final iv = enc.IV(base64.decode(parts[0]));
    final encrypter = enc.Encrypter(enc.AES(key));
    return encrypter.decrypt(enc.Encrypted.fromBase64(parts[1]), iv: iv);
  }
}