import 'package:flutter/material.dart';
import 'lib/simulation/marketplace_simulation.dart';

void main() {
  runApp(const DisasterSimApp());
}

class DisasterSimApp extends StatelessWidget {
  const DisasterSimApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Disaster Agent Marketplace',
      home: Scaffold(
        appBar: AppBar(title: const Text('Disaster Agent Marketplace Simülasyon')),
        body: Center(
          child: ElevatedButton(
            child: const Text('Simülasyonu Çalıştır'),
            onPressed: () {
              simulateDistributedTaskAssignment();
            },
          ),
        ),
      ),
    );
  }
}