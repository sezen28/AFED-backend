import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class AppLogger extends Logger {
  // Merkezi loglama için örn. ELK/Sentry/CloudWatch'e entegre edilebilir
  error(message: string, trace: string) {
    super.error(message, trace);
    // Burada harici servise gönderim yapılabilir
  }
}