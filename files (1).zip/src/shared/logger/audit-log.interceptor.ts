import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { Logger } from '@nestjs/common';

@Injectable()
export class AuditLogInterceptor implements NestInterceptor {
  private readonly logger = new Logger('AuditLog');

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const user = req.user;
    const action = `${req.method} ${req.url}`;

    return next.handle().pipe(
      tap(() => {
        this.logger.log(
          `User: ${user?.email || 'anonymous'} Action: ${action} At: ${new Date().toISOString()}`,
        );
      }),
    );
  }
}