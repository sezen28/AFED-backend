import { Module } from '@nestjs/common';

import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { AlertsModule } from './modules/alerts/alerts.module';
import { MapModule } from './modules/map/map.module';
import { CommunityModule } from './modules/community/community.module';
import { AiModule } from './modules/ai/ai.module';
import { KnowledgeModule } from './modules/knowledge/knowledge.module';
import { DonationsModule } from './modules/donations/donations.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { ModerationModule } from './modules/moderation/moderation.module';
import { AdminModule } from './modules/admin/admin.module';
import { MonitoringModule } from './modules/monitoring/monitoring.module';
import { LocalizationModule } from './modules/localization/localization.module';
import { CrisisModule } from './modules/crisis/crisis.module';

@Module({
  imports: [
    AuthModule,
    UsersModule,
    AlertsModule,
    MapModule,
    CommunityModule,
    AiModule,
    KnowledgeModule,
    DonationsModule,
    NotificationsModule,
    ModerationModule,
    AdminModule,
    MonitoringModule,
    LocalizationModule,
    CrisisModule
  ],
})
export class AppModule {}