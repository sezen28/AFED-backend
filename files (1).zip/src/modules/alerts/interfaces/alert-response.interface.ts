export interface AlertResponse {
  id: string;
  type: string;
  title: string;
  description: string;
  latitude: number;
  longitude: number;
  risk_level: string;
  created_at: string;
  source: string;
}