import { Alert } from '../domain/alert.entity';
import { CreateAlertDto } from '../application/dto/create-alert.dto';

export interface IAlertService {
  createAlert(dto: CreateAlertDto): Promise<Alert>;
  getActiveAlerts(): Promise<Alert[]>;
  deactivateAlert(id: string): Promise<Alert>;
}