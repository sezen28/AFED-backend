import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { AlertService } from '../application/alert.service';
import { CreateAlertDto } from '../application/dto/create-alert.dto';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';
import { Roles } from '../../../shared/decorators/roles.decorator';
import { RolesGuard } from '../../../shared/guards/roles.guard';

@Controller('alerts')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AlertsController {
  constructor(private readonly alertService: AlertService) {}

  @Roles('admin')
  @Post()
  async createAlert(@Body() dto: CreateAlertDto) {
    return this.alertService.createAlert(dto);
  }

  @Roles('admin', 'user')
  @Get()
  async getActiveAlerts() {
    return this.alertService.getActiveAlerts();
  }
}