import { IAlertService } from '../interfaces/alert-service.interface';
import { Alert } from '../domain/alert.entity';
import { CreateAlertDto } from './dto/create-alert.dto';

export class AlertServiceMock implements IAlertService {
  createAlert(dto: CreateAlertDto): Promise<Alert> {
    return Promise.resolve({
      ...dto,
      id: 'test-id',
      is_active: true,
      created_at: new Date(),
    } as Alert);
  }
  getActiveAlerts(): Promise<Alert[]> {
    return Promise.resolve([]);
  }
  deactivateAlert(id: string): Promise<Alert> {
    return Promise.resolve({ id, is_active: false } as Alert);
  }
}