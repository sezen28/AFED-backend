import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alert } from '../domain/alert.entity';
import { CreateAlertDto } from './dto/create-alert.dto';

@Injectable()
export class AlertService {
  private readonly logger = new Logger(AlertService.name);

  constructor(
    @InjectRepository(Alert)
    private readonly alertRepository: Repository<Alert>,
  ) {}

  async createAlert(dto: CreateAlertDto): Promise<Alert> {
    const alert = this.alertRepository.create(dto);
    this.logger.log(`Creating alert: ${JSON.stringify(alert)}`);
    return this.alertRepository.save(alert);
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return this.alertRepository.find({ where: { is_active: true } });
  }

  async deactivateAlert(id: string) {
    const alert = await this.alertRepository.findOne({ where: { id } });
    if (!alert) throw new NotFoundException('Alert not found');
    alert.is_active = false;
    return this.alertRepository.save(alert);
  }
}