// Parola ve profil yönetimi, child profile, KVKK uyumu için genişletilebilir
import { Injectable, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../domain/user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
  ) {}

  async register(email: string, password: string, display_name: string) {
    if (await this.userRepo.findOne({ where: { email } })) {
      throw new ConflictException('Email already registered');
    }
    const user = this.userRepo.create({
      email,
      display_name,
      password_hash: await bcrypt.hash(password, 10),
    });
    return this.userRepo.save(user);
  }

  async findByEmail(email: string) {
    return this.userRepo.findOne({ where: { email } });
  }

  // Çocuk profili, KVKK vb. burada yönetilebilir
}