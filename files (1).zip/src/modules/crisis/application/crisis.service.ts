import { Injectable } from '@nestjs/common';

@Injectable()
export class CrisisService {
  getCrisisModeInfo() {
    return {
      offlineMode: true,
      powerSave: true,
      emergencySignal: true,
    };
  }
}