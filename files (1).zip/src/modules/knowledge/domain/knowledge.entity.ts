import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Knowledge {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  title: string;

  @Column('text')
  content: string;

  @Column()
  type: string; // guide, quiz, simulation

  @Column({ default: true })
  is_active: boolean;
}