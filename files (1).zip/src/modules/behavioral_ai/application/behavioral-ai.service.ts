import { Injectable } from '@nestjs/common';

@Injectable()
export class BehavioralAIService {
  async analyzeBehavior(userId: string, events: any[]) {
    // Kullanıcı etkileşimlerinden öneri üretir (ör: yeniden bildirim, hazırlık önerisi)
    // Burada AI mikroservisine veya modele istek gönderilebilir
    return {
      tips: ['Deprem çantası hazırlayın', 'En yakın toplanma noktasını kontrol edin'],
    };
  }
}