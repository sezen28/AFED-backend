import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HelpRequest } from '../../community/domain/help-request.entity';

@Injectable()
export class ModerationService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly helpRepo: Repository<HelpRequest>,
  ) {}

  async getReportedRequests() {
    return this.helpRepo.find({ where: { reported: true } });
  }

  async moderateRequest(id: string, action: 'approve' | 'remove') {
    const req = await this.helpRepo.findOne({ where: { id } });
    if (!req) throw new Error('Request not found');
    if (action === 'remove') req.status = 'removed';
    else req.reported = false;
    await this.helpRepo.save(req);
    return req;
  }
}