import { Injectable } from '@nestjs/common';

@Injectable()
export class LocalizationService {
  async getAvailableLanguages() {
    return ['tr', 'en', 'ar'];
  }

  async getTranslations(lang: string) {
    if (lang === 'tr') return { welcome: 'Hoşgeldiniz!' };
    if (lang === 'en') return { welcome: 'Welcome!' };
    if (lang === 'ar') return { welcome: 'مرحبا!' };
    return {};
  }
}