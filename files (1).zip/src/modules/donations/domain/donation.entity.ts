import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class Donation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  campaign: string;

  @Column()
  donor_name: string;

  @Column()
  amount: number;

  @Column()
  currency: string;

  @CreateDateColumn()
  donated_at: Date;
}