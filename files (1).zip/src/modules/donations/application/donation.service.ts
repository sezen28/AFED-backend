import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Donation } from '../domain/donation.entity';

@Injectable()
export class DonationService {
  constructor(
    @InjectRepository(Donation)
    private readonly donationRepo: Repository<Donation>,
  ) {}

  async donate(data: { campaign: string; donor_name: string; amount: number; currency: string }) {
    const donation = this.donationRepo.create(data);
    return this.donationRepo.save(donation);
  }

  async getCampaignDonations(campaign: string) {
    return this.donationRepo.find({ where: { campaign } });
  }
}