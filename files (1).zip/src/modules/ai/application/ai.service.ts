import { Injectable, Logger } from '@nestjs/common';
import { AiMessageDto } from './dto/ai-message.dto';
import axios from 'axios';

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  async chatWithBot(dto: AiMessageDto) {
    try {
      const response = await axios.post('http://localhost:8000/api/bot/message', dto, { timeout: 5000 });
      return response.data;
    } catch (e) {
      this.logger.error('AI Bot service unreachable', e);
      return { reply: 'Şu an yardımcı olamıyorum. Lütfen tekrar deneyin.' };
    }
  }
}