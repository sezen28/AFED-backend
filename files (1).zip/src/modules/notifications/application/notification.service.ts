import { Injectable } from '@nestjs/common';
import * as admin from 'firebase-admin';

@Injectable()
export class NotificationService {
  async sendPush(token: string, title: string, body: string, data?: Record<string, string>) {
    return admin.messaging().send({
      token,
      notification: { title, body },
      data: data || {},
    });
  }
}