export default () => ({
  database: {
    url: process.env.DATABASE_URL,
  },
  auth: {
    jwtSecret: process.env.JWT_SECRET,
  },
  aiService: {
    endpoint: process.env.AI_SERVICE_URL,
  },
});