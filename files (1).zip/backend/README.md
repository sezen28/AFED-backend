# MetaMesh Node

- Her node, kendi mesh ağına ve MetaMesh protokolüne bağlıdır.
- Olaylar, hem mesh’te hem de MetaMesh’te, hem de blockchain üzerinde izlenir.
- AI parametreleri federated learning ile güncellenir, model swarm ile paylaşılır.
- Her node, sadece gerekli minimum meta-data’yı paylaşır (privacy by default).
- Veri ve model güncellemeleri IPFS, Swarm, veya Filecoin gibi merkeziyetsiz depolarda saklanabilir.

## Akış:
1. Olay/Sensör/İstek gelir.
2. AI analiz, öncelik ve güvenilirlik hesaplar.
3. Olay mesh’te ve MetaMesh’te relay edilir.
4. Blockchain’e hash/provenance kaydı yapılır.
5. Federated learning ile model güncellenir ve paylaşılır.
