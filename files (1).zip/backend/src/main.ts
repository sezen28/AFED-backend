import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import helmet from 'helmet';
import * as rateLimit from 'express-rate-limit';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.use(helmet()); // Güvenlik başlıkları
  app.enableCors();
  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000, // 15 dakika
      max: 100, // IP başına 100 istek limiti
    }),
  );
  await app.listen(3000);
}
bootstrap();