import { Controller, Post, Body } from '@nestjs/common';
import { AiService } from './ai.service';
import { AiMessageDto } from './dto/ai-message.dto';

@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('bot/message')
  async chat(@Body() dto: AiMessageDto) {
    return this.aiService.chatWithBot(dto);
  }
}