import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true, nullable: true })
  email: string;

  @Column()
  password_hash: string;

  @Column()
  display_name: string;

  @Column({ default: 'user' })
  role: string; // user, admin, child

  @Column({ default: false })
  is_anonymous: boolean;

  @Column({ default: false })
  mfa_enabled: boolean;

  @CreateDateColumn()
  created_at: Date;
}