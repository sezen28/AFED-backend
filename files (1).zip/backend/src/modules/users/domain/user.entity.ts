import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, OneToMany, Index } from 'typeorm';
import { HelpRequest } from '../../help/domain/help-request.entity';

@Entity()
@Index(['email'], { unique: true })
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column()
  full_name: string;

  @Column({ default: 'user' })
  role: string; // user, admin, volunteer

  @CreateDateColumn()
  created_at: Date;

  @OneToMany(() => HelpRequest, help => help.user)
  helpRequests: HelpRequest[];
}