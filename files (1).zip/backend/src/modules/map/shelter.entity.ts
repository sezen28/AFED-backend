import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Shelter {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // shelter, hospital, gathering_point

  @Column()
  capacity: number;

  @Column()
  available: number;
}