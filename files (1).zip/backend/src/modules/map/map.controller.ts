import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { MapService } from './map.service';
import { CreateShelterDto } from './dto/create-shelter.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';

@Controller('map')
export class MapController {
  constructor(private readonly mapService: MapService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Post('shelter')
  async createShelter(@Body() dto: CreateShelterDto) {
    return this.mapService.createShelter(dto);
  }

  @Get('shelters')
  async getAllShelters() {
    return this.mapService.getAllShelters();
  }
}