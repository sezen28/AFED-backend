import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Shelter } from './shelter.entity';
import { CreateShelterDto } from './dto/create-shelter.dto';

@Injectable()
export class MapService {
  constructor(
    @InjectRepository(Shelter)
    private readonly shelterRepo: Repository<Shelter>,
  ) {}

  async createShelter(dto: CreateShelterDto): Promise<Shelter> {
    const shelter = this.shelterRepo.create(dto);
    return this.shelterRepo.save(shelter);
  }

  async getAllShelters(): Promise<Shelter[]> {
    return this.shelterRepo.find();
  }
}