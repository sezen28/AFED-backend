import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { AlertService } from '../application/alert.service';

@Controller('alerts')
export class AlertController {
  constructor(private readonly service: AlertService) {}

  @Get()
  async list() {
    return this.service.list();
  }

  @Get(':id')
  async get(@Param('id') id: string) {
    return this.service.get(id);
  }

  @Post()
  async create(@Body() body: any) {
    return this.service.create(body);
  }
}