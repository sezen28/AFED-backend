import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alert } from './alert.entity';
import { CreateAlertDto } from './dto/create-alert.dto';

@Injectable()
export class AlertsService {
  constructor(
    @InjectRepository(Alert)
    private readonly alertRepo: Repository<Alert>,
  ) {}

  async createAlert(dto: CreateAlertDto): Promise<Alert> {
    const alert = this.alertRepo.create(dto);
    return this.alertRepo.save(alert);
  }

  async getActiveAlerts(): Promise<Alert[]> {
    return this.alertRepo.find({ where: { is_active: true } });
  }
}