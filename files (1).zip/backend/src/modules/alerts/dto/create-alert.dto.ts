import { IsString, IsNotEmpty, IsIn } from 'class-validator';

export class CreateAlertDto {
  @IsString()
  @IsIn(['earthquake', 'flood', 'fire', 'other'])
  type: string;

  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsString()
  @IsNotEmpty()
  location: string; // GeoJSON Point string

  @IsString()
  @IsIn(['low', 'medium', 'high'])
  risk_level: string;

  @IsString()
  source: string;
}