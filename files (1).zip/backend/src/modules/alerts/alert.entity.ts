import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity()
export class Alert {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  type: string; // earthquake, flood, fire

  @Column()
  title: string;

  @Column('text')
  description: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  risk_level: string; // low, medium, high

  @Column()
  source: string; // official, user, social

  @Column({ default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;
}