import { Controller, Get } from '@nestjs/common';
import { KnowledgeService } from '../knowledge/knowledge.service';

@Controller('crisis')
export class CrisisController {
  constructor(private readonly knowledgeService: KnowledgeService) {}

  @Get('offline-knowledge')
  async getOfflineKnowledge() {
    // Cihazda offline tutulacak bilgilendirme içeriklerinin toplu JSON'u
    return this.knowledgeService.getKnowledge();
  }
}