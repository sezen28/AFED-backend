import { Controller, Patch, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ModerationService } from './moderation.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';

@Controller('moderation')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('admin', 'moderator')
export class ModerationController {
  constructor(private readonly moderationService: ModerationService) {}

  @Get('reported')
  getReportedRequests() {
    return this.moderationService.getReportedRequests();
  }

  @Patch('request/:id')
  moderateRequest(@Param('id') id: string, @Query('action') action: 'approve' | 'remove') {
    return this.moderationService.moderateRequest(id, action);
  }
}