import { Controller, Get, Post, Body, Query, UseGuards } from '@nestjs/common';
import { KnowledgeService } from './knowledge.service';
import { CreateKnowledgeDto } from './dto/create-knowledge.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';

@Controller('knowledge')
export class KnowledgeController {
  constructor(private readonly knowledgeService: KnowledgeService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Post()
  async createKnowledge(@Body() dto: CreateKnowledgeDto) {
    return this.knowledgeService.createKnowledge(dto);
  }

  @Get()
  async getKnowledge(@Query('type') type?: string) {
    return this.knowledgeService.getKnowledge(type);
  }
}