import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Knowledge } from './knowledge.entity';
import { CreateKnowledgeDto } from './dto/create-knowledge.dto';

@Injectable()
export class KnowledgeService {
  constructor(
    @InjectRepository(Knowledge)
    private readonly knowledgeRepo: Repository<Knowledge>,
  ) {}

  async createKnowledge(dto: CreateKnowledgeDto): Promise<Knowledge> {
    const knowledge = this.knowledgeRepo.create(dto);
    return this.knowledgeRepo.save(knowledge);
  }

  async getKnowledge(type?: string) {
    if (type) {
      return this.knowledgeRepo.find({ where: { type, is_active: true } });
    }
    return this.knowledgeRepo.find({ where: { is_active: true } });
  }
}