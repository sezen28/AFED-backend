import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  Index,
  OneToMany
} from 'typeorm';
import { User } from '../../users/domain/user.entity';
import { Shelter } from '../../shelters/domain/shelter.entity';
import { Disaster } from '../../disasters/domain/disaster.entity';
import { HelpRequestLog } from './help-request-log.entity';

@Entity()
@Index(['status', 'priority'])
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User, user => user.helpRequests, { eager: true })
  user: User;

  @ManyToOne(() => Shelter, { nullable: true, eager: true })
  shelter: Shelter;

  @ManyToOne(() => Disaster, { nullable: true, eager: true })
  disaster: Disaster;

  @Column('text')
  description: string;

  @Column({ type: 'varchar', default: 'open' })
  status: string; // open | assigned | closed

  @Column({ type: 'varchar', default: 'med' })
  priority: string; // low | med | high | crit

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  @Index({ spatial: true })
  location: string;

  @Column('jsonb', { nullable: true })
  files: string[]; // Dosya URL dizisi

  @OneToMany(() => HelpRequestLog, log => log.helpRequest)
  logs: HelpRequestLog[];

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  @Column({ type: 'int', default: 1 })
  version: number;

  @Column({ default: true })
  is_active: boolean;
}