import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne } from 'typeorm';
import { HelpRequest } from './help-request.entity';
import { User } from '../../users/domain/user.entity';

@Entity()
export class HelpRequestLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => HelpRequest, help => help.logs)
  helpRequest: HelpRequest;

  @ManyToOne(() => User)
  user: User;

  @Column()
  action: string; // created | updated | closed | note | assigned

  @Column({ nullable: true })
  note: string;

  @CreateDateColumn()
  created_at: Date;
}