import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { HelpRequest } from '../domain/help-request.entity';
import { Repository } from 'typeorm';

@Injectable()
export class HelpRequestService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly repo: Repository<HelpRequest>
  ) {}

  async listHelpRequests(since?: Date): Promise<HelpRequest[]> {
    const where: any = { is_active: true };
    if (since) where.updated_at = { $gt: since };
    return this.repo.find({ where, order: { updated_at: 'DESC' } });
  }

  async getHelpRequestById(id: string): Promise<HelpRequest> {
    const req = await this.repo.findOne({ where: { id, is_active: true } });
    if (!req) throw new NotFoundException('Help request not found');
    return req;
  }

  async createHelpRequest(body: any): Promise<HelpRequest> {
    const entity = this.repo.create(body);
    return await this.repo.save(entity);
  }

  async updateHelpRequest(id: string, body: any): Promise<HelpRequest> {
    const current = await this.getHelpRequestById(id);
    if (body.version && body.version !== current.version) {
      throw new ConflictException({ message: 'Version conflict', server: current });
    }
    Object.assign(current, body, { version: current.version + 1 });
    return await this.repo.save(current);
  }
}