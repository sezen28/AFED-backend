import { Test, TestingModule } from '@nestjs/testing';
import { HelpRequestService } from './help-request.service';
import { getRepositoryToken } from '@nestjs/typeorm';
import { HelpRequest } from '../domain/help-request.entity';
import { Repository } from 'typeorm';

describe('HelpRequestService', () => {
  let service: HelpRequestService;
  let repo: Repository<HelpRequest>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HelpRequestService,
        {
          provide: getRepositoryToken(HelpRequest),
          useClass: Repository,
        },
      ],
    }).compile();

    service = module.get<HelpRequestService>(HelpRequestService);
    repo = module.get<Repository<HelpRequest>>(getRepositoryToken(HelpRequest));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should create help request', async () => {
    const data = { description: 'Yardım', status: 'open', priority: 'high', location: 'POINT(1 2)' };
    jest.spyOn(repo, 'create').mockReturnValue(data as any);
    jest.spyOn(repo, 'save').mockResolvedValue({ ...data, id: '1' } as any);
    const result = await service.createHelpRequest(data);
    expect(result.description).toBe('Yardım');
  });
});