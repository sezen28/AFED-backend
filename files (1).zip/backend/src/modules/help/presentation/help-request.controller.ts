import { Controller, Get, Post, Body, Param, Put, Query, UseGuards, ConflictException } from '@nestjs/common';
import { HelpRequestService } from '../application/help-request.service';
import { JwtAuthGuard } from '../../../shared/guards/jwt-auth.guard';

@Controller('help-requests')
@UseGuards(JwtAuthGuard)
export class HelpRequestController {
  constructor(private readonly service: HelpRequestService) {}

  @Get()
  async list(@Query('since') since?: string) {
    return this.service.listHelpRequests(since ? new Date(since) : undefined);
  }

  @Get(':id')
  async get(@Param('id') id: string) {
    return this.service.getHelpRequestById(id);
  }

  @Post()
  async create(@Body() body: any) {
    return this.service.createHelpRequest(body);
  }

  @Put(':id')
  async update(@Param('id') id: string, @Body() body: any) {
    try {
      return await this.service.updateHelpRequest(id, body);
    } catch (e) {
      if (e instanceof ConflictException) throw e;
      throw e;
    }
  }
}