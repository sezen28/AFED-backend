import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/domain/user.entity';

@Entity()
export class Donation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @ManyToOne(() => User)
  user: User;

  @Column()
  type: string; // money, goods, food, etc.

  @Column('decimal', { nullable: true })
  amount: number;

  @Column({ nullable: true })
  description: string;

  @CreateDateColumn()
  created_at: Date;
}