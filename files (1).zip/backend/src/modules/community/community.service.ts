import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { HelpRequest } from './help-request.entity';
import { CreateHelpRequestDto } from './dto/create-help-request.dto';

@Injectable()
export class CommunityService {
  constructor(
    @InjectRepository(HelpRequest)
    private readonly helpRepo: Repository<HelpRequest>,
  ) {}

  async createHelpRequest(dto: CreateHelpRequestDto, userId: string): Promise<HelpRequest> {
    const req = this.helpRepo.create({ ...dto, user_id: userId });
    return this.helpRepo.save(req);
  }

  async getOpenRequests(): Promise<HelpRequest[]> {
    return this.helpRepo.find({ where: { status: 'open' } });
  }
}