import { IsString, IsNotEmpty } from 'class-validator';

export class CreateHelpRequestDto {
  @IsString()
  @IsNotEmpty()
  type: string;

  @IsString()
  @IsNotEmpty()
  description: string;

  @IsString()
  @IsNotEmpty()
  location: string; // GeoJSON Point string
}