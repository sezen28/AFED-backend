import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';

@Entity()
export class HelpRequest {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: true })
  user_id: string;

  @Column('geometry', { spatialFeatureType: 'Point', srid: 4326 })
  location: string;

  @Column()
  type: string; // rescue, food, medical, other

  @Column()
  description: string;

  @Column({ default: 'open' })
  status: string; // open, matched, closed

  @Column({ default: false })
  reported: boolean;

  @CreateDateColumn()
  created_at: Date;
}