import { Controller, Post, Get, Body, UseGuards, Req } from '@nestjs/common';
import { CommunityService } from './community.service';
import { CreateHelpRequestDto } from './dto/create-help-request.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';

@Controller('community')
export class CommunityController {
  constructor(private readonly communityService: CommunityService) {}

  @UseGuards(JwtAuthGuard)
  @Post('help-request')
  async createHelpRequest(@Body() dto: CreateHelpRequestDto, @Req() req) {
    return this.communityService.createHelpRequest(dto, req.user.id);
  }

  @Get('help-requests')
  async getOpenRequests() {
    return this.communityService.getOpenRequests();
  }
}