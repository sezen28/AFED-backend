import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';

import { AlertsModule } from './modules/alerts/alerts.module';
import { UsersModule } from './modules/users/users.module';
import { CommunityModule } from './modules/community/community.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      url: process.env.DATABASE_URL,
      autoLoadEntities: true,
      synchronize: false, // production için false!
      ssl: { rejectUnauthorized: false },
    }),
    AlertsModule,
    UsersModule,
    CommunityModule,
  ],
})
export class AppModule {}