import * as crypto from 'crypto';

const AES_KEY = process.env.AES_KEY!; // 32 bytes

export function decryptPayload(payload: string): string {
  const [ivB64, dataB64] = payload.split(':');
  const iv = Buffer.from(ivB64, 'base64');
  const encrypted = Buffer.from(dataB64, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY, 'base64'), iv);
  let decrypted = decipher.update(encrypted);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}