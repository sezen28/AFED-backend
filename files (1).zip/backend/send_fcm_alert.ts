import fetch from 'node-fetch';

export async function sendFCM(token: string, title: string, body: string, route: string) {
  const serverKey = 'FIREBASE_SERVER_KEY'; // FCM sunucu anahtarın
  await fetch('https://fcm.googleapis.com/fcm/send', {
    method: 'POST',
    headers: {
      'Authorization': `key=${serverKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      to: token,
      notification: { title, body },
      data: { route },
    }),
  });
}