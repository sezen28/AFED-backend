import numpy as np
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

def prioritize_and_cluster(help_requests):
    # help_requests: [{'lat':..., 'lon':..., 'desc':...}, ...]
    coords = np.array([[r['lat'], r['lon']] for r in help_requests])
    descriptions = [r['desc'] for r in help_requests]
    vectorizer = TfidfVectorizer().fit_transform(descriptions)
    # Kümelendirme
    kmeans = KMeans(n_clusters=3).fit(coords)
    clusters = kmeans.labels_
    # Basit TF-IDF ile öncelik skoru
    priority_scores = vectorizer.max(axis=1).toarray().flatten()
    return clusters, priority_scores